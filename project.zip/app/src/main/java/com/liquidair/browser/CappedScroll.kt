package com.liquidair.browser

import android.content.Context
import android.widget.HorizontalScrollView

/**
 * A scroll view that is exactly as wide as its content until it reaches [cap]. The tab strip uses
 * it so the + button sits directly after the last tab and moves with it on every frame.
 */
class CappedScroll(ctx: Context) : HorizontalScrollView(ctx) {
    var cap = Int.MAX_VALUE

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = MeasureSpec.getSize(widthMeasureSpec)
        val limit = if (size > 0) minOf(size, cap) else cap
        super.onMeasure(MeasureSpec.makeMeasureSpec(limit, MeasureSpec.AT_MOST), heightMeasureSpec)
    }
}
