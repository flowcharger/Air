package com.liquidair.browser

import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.animation.ValueAnimator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

/**
 * The gear next to the address bar. It opens a panel right under the icon: whether the connection
 * is secure, how many ads and trackers were stopped on this page, and the controls for this site
 * (shields, scripts, cookies, location, camera, microphone). It is a plain Chrome-style card.
 */
class SitePanel(private val act: MainActivity) {

    private var popup: PopupWindow? = null
    private var anchorBtn: View? = null
    private var tab: Tab? = null
    private var host = ""
    private var panelW = 0
    private var maxH = 0
    private var card: FrameLayout? = null
    private var stack: FrameLayout? = null
    private var currentKey = "main"
    private var currentView: View? = null
    private var currentCol: LinearLayout? = null
    private var animating = false
    private var savedBg: android.graphics.drawable.Drawable? = null
    private var heightAnim: ValueAnimator? = null

    private val subColor get() = C.MUTED
    private val linkColor get() = C.LINK

    fun toggle(tab: Tab, anchor: View) {
        if (popup != null) {
            close()
            return
        }
        if (tab.home || !Urls.isWeb(tab.url)) {
            act.toast("Open a website to see its status")
            return
        }
        show(tab, anchor)
    }

    fun close() {
        heightAnim?.cancel()
        popup?.dismiss()
        popup = null
        animating = false
        twist(false)
    }

    private fun dp(v: Int) = act.dp(v)

    /** While the panel is open the gear sits in a soft round highlight and the page dims. */
    private fun twist(on: Boolean) {
        act.dimPage(on)
        val b = anchorBtn ?: return
        if (on) {
            if (savedBg == null) savedBg = b.background
            val d = GradientDrawable()
            d.shape = GradientDrawable.OVAL
            d.setColor(C.SHADE)
            d.alpha = 0
            b.background = d
            ValueAnimator.ofInt(0, 255).apply {
                duration = Motion.NORMAL
                interpolator = Motion.STD
                addUpdateListener { d.alpha = it.animatedValue as Int }
                start()
            }
        } else {
            val d = b.background ?: return
            val keep = savedBg
            ValueAnimator.ofInt(255, 0).apply {
                duration = Motion.NORMAL
                interpolator = Motion.STD
                addUpdateListener { d.alpha = it.animatedValue as Int }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: android.animation.Animator) {
                        b.background = keep
                        savedBg = null
                    }
                })
                start()
            }
        }
    }

    private fun show(tab: Tab, anchor: View) {
        this.tab = tab
        host = Urls.hostOf(tab.url)
        anchorBtn = anchor
        currentKey = "main"
        animating = false

        val metrics = act.resources.displayMetrics
        panelW = minOf(dp(364), metrics.widthPixels - dp(16))
        maxH = metrics.heightPixels - dp(190)

        val cardView = FrameLayout(act)
        cardView.background = GradientDrawable().apply {
            cornerRadius = act.dpf(14f)
            setColor(C.WHITE)
            setStroke(act.dp(1), C.LINE)
        }
        cardView.clipToOutline = true
        cardView.elevation = act.dpf(8f)
        card = cardView

        val st = FrameLayout(act)
        stack = st
        cardView.addView(st, FrameLayout.LayoutParams(-1, -1))

        val (first, col) = page("main")
        st.addView(first, FrameLayout.LayoutParams(-1, -1))
        currentView = first
        currentCol = col

        // A little transparent margin lets the card's shadow show. The window is as tall as the
        // card can ever be, and only the card inside it changes height, so changing pages never
        // has to resize the window.
        val m = dp(10)
        val frame = FrameLayout(act)
        frame.clipChildren = false
        frame.clipToPadding = false
        frame.setPadding(m, m, m, m)
        frame.setOnClickListener { close() }
        frame.addView(cardView, FrameLayout.LayoutParams(panelW, targetHeight(col)))

        val pop = PopupWindow(frame, panelW + 2 * m, maxH + 2 * m, true)
        pop.setBackgroundDrawable(null)
        pop.isOutsideTouchable = true
        pop.setOnDismissListener {
            heightAnim?.cancel()
            popup = null
            animating = false
            twist(false)
        }
        popup = pop
        pop.showAsDropDown(anchor, -dp(6) - m, dp(8) - m)
        twist(true)
        cardView.pivotX = 0f
        cardView.pivotY = 0f
        cardView.arrive(0f, -6f, .97f, Motion.NORMAL)
    }

    // ---- pages ----------------------------------------------------------------

    /** A scrolling page for one screen of the panel. Opaque, so a page sliding over another hides it. */
    private fun page(key: String): Pair<ScrollView, LinearLayout> {
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(act)
        sv.isVerticalScrollBarEnabled = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        sv.setBackgroundColor(C.WHITE)
        sv.addView(col, ViewGroup.LayoutParams(-1, -2))
        build(key, col)
        return Pair(sv, col)
    }

    private fun build(key: String, col: LinearLayout) {
        col.removeAllViews()
        col.pad(4, 4, 4, 6)
        val t = tab ?: return
        when (key) {
            "shields" -> fillShields(col, t)
            "conn" -> fillConn(col, t)
            "cookies" -> fillCookies(col)
            "perms" -> fillPerms(col)
            else -> fillMain(col, t)
        }
    }

    private fun targetHeight(col: LinearLayout): Int {
        col.measure(
            View.MeasureSpec.makeMeasureSpec(panelW, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        return minOf(col.measuredHeight, maxH)
    }

    private fun setCardHeight(h: Int) {
        val c = card ?: return
        c.layoutParams.height = h
        c.requestLayout()
    }

    private fun animateHeight(to: Int) {
        val c = card ?: return
        val from = c.layoutParams.height
        if (from == to) return
        heightAnim?.cancel()
        val a = ValueAnimator.ofInt(from, to)
        a.duration = Motion.NORMAL
        a.interpolator = Motion.STD
        a.addUpdateListener { setCardHeight(it.animatedValue as Int) }
        heightAnim = a
        a.start()
    }

    /** Rebuilds the page you are on (a switch changed) and eases the card to its new height. */
    private fun refresh() {
        val col = currentCol ?: return
        if (animating) return
        build(currentKey, col)
        animateHeight(targetHeight(col))
    }

    /** Slides to another page: forward pushes it in from the right, back slides it away to the right. */
    private fun go(key: String, forward: Boolean) {
        if (animating || key == currentKey) return
        val st = stack ?: return
        val old = currentView ?: return
        val (next, ncol) = page(key)
        val w = panelW.toFloat()
        val shift = w * 0.28f
        val fromH = (card?.layoutParams?.height ?: 0)
        val toH = targetHeight(ncol)

        if (forward) {
            st.addView(next, FrameLayout.LayoutParams(-1, -1))
            next.translationX = w
        } else {
            // The page we are going back to waits underneath; the one we leave slides off on top.
            st.addView(next, 0, FrameLayout.LayoutParams(-1, -1))
            next.translationX = -shift
            next.alpha = 0f
            old.bringToFront()
        }
        animating = true
        heightAnim?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = Motion.SLOW
        a.interpolator = Motion.STD
        a.addUpdateListener {
            val p = it.animatedValue as Float
            if (forward) {
                next.translationX = w * (1f - p)
                old.translationX = -shift * p
                old.alpha = 1f - 0.6f * p
            } else {
                next.translationX = -shift * (1f - p)
                next.alpha = p
                old.translationX = w * p
            }
            setCardHeight(fromH + ((toH - fromH) * p).toInt())
        }
        a.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                st.removeView(old)
                next.translationX = 0f
                next.alpha = 1f
                currentView = next
                currentCol = ncol
                currentKey = key
                animating = false
                setCardHeight(toH)
            }
        })
        heightAnim = a
        a.start()
    }

    /** Top bar of a sub page: a back arrow and the page's name, like Brave's. */
    private fun subHeader(col: LinearLayout, title: String) {
        val header = LinearLayout(act)
        header.gravity = Gravity.CENTER_VERTICAL
        header.pad(4, 6, 16, 6)
        val back = iconButton(act, R.drawable.ic_back, 44, 44, 22, "Back")
        back.setOnClickListener { go("main", false) }
        header.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        header.addView(
            oneLine(text(act, title, 18f, C.INK, true)),
            LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(6) }
        )
        col.addView(header)
        col.addView(divider().also { (it.layoutParams as LinearLayout.LayoutParams).leftMargin = 0 })
    }

    // ---- contents -------------------------------------------------------

    private fun fillMain(col: LinearLayout, tab: Tab) {
        val prefs = act.prefs
        val secure = tab.url.startsWith("https://", true)
        val shieldsUp = prefs.adBlock && Sites.ads(host)

        // ---- header: the site and a close button ----
        val header = LinearLayout(act)
        header.gravity = Gravity.CENTER_VERTICAL
        header.pad(16, 6, 4, 6)
        header.addView(
            oneLine(text(act, host.removePrefix("www.").ifEmpty { tab.url }, 18f, C.INK, true)),
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        val x = iconButton(act, R.drawable.ic_close, 44, 44, 20, "Close")
        x.setOnClickListener { close() }
        header.addView(x, LinearLayout.LayoutParams(dp(44), dp(44)))
        col.addView(header)

        // ---- connection ----
        col.addView(divider())
        col.addView(
            row(
                R.drawable.ic_lock,
                if (secure) "Connection is secure" else "Connection is not secure",
                if (secure) null else "Others on the network may see what you send",
                "conn", null
            )
        )

        // ---- ads and trackers (the Shields switch; tapping the row opens the details) ----
        col.addView(divider())
        val total = tab.blocked + SiteBridge.blockedFor(host)
        col.addView(
            row(
                R.drawable.ic_shield,
                "Air Block",
                if (shieldsUp) "$total ads and trackers blocked on this page" else "Off for this site",
                "shields",
                switchView(shieldsUp) { on ->
                    if (on && !prefs.adBlock) {
                        if (!prefs.adBlockExt) {
                            act.toast("Air Block is turned off in Extensions. Switch it on there first.")
                            refresh()
                            return@switchView
                        }
                        prefs.adBlock = true
                        Engine.apply(prefs)
                    }
                    Sites.setAds(host, on)
                    tab.session.settings.useTrackingProtection = prefs.adBlock && on && !Urls.fragile(host)
                    reload(tab)
                    refresh()
                }
            )
        )

        // ---- JavaScript ----
        col.addView(divider())
        col.addView(
            row(
                R.drawable.ic_code,
                "JavaScript",
                if (Sites.js(host)) "Allowed" else "Blocked on this site",
                null,
                switchView(Sites.js(host)) { on ->
                    Sites.setJs(host, on)
                    reload(tab)
                    refresh()
                }
            )
        )

        // ---- cookies ----
        col.addView(divider())
        col.addView(row(R.drawable.ic_cookie, "Cookies and site data", cookieNames[prefs.cookieMode.coerceIn(0, 3)], "cookies", null))

        // ---- permissions ----
        col.addView(divider())
        col.addView(row(R.drawable.ic_tune, "Permissions", permissionSummary(), "perms", null))

        // ---- shred ----
        col.addView(divider())
        col.addView(
            row(R.drawable.ic_trash, "Shred site data", "Cookies, storage and cache for this site", null, null).also { r ->
                r.setOnClickListener { shred(tab) }
            }
        )

        // ---- footer ----
        col.addView(divider())
        val foot = LinearLayout(act)
        foot.gravity = Gravity.CENTER_VERTICAL
        foot.pad(16, 4, 12, 2)
        if (Sites.customised(host)) {
            val reset = text(act, "Reset for this site", 14.5f, linkColor, true)
            reset.pad(0, 10, 16, 10)
            reset.setOnClickListener {
                Sites.reset(host)
                tab.session.settings.useTrackingProtection = prefs.adBlock && !Urls.fragile(host)
                reload(tab)
                refresh()
            }
            foot.addView(reset)
        }
        val more = text(act, "Privacy settings", 14.5f, linkColor, true)
        more.pad(0, 10, 0, 10)
        more.setOnClickListener {
            close()
            act.openSettings("privacy")
        }
        foot.addView(more)
        col.addView(foot)
    }

    private val cookieNames = arrayOf("Allow all cookies", "Block cross-site cookies", "Block third-party cookies", "Block all cookies")
    private val askWords = arrayOf("Ask", "Allow", "Block")

    private fun permissionSummary(): String {
        val parts = ArrayList<String>()
        if (Sites.location(host) != Sites.ASK) parts.add("Location " + askWords[Sites.location(host).coerceIn(0, 2)].lowercase())
        if (Sites.camera(host) != Sites.ASK) parts.add("Camera " + askWords[Sites.camera(host).coerceIn(0, 2)].lowercase())
        if (Sites.mic(host) != Sites.ASK) parts.add("Microphone " + askWords[Sites.mic(host).coerceIn(0, 2)].lowercase())
        if (Sites.drm(host) != Sites.ASK) parts.add("Protected content " + askWords[Sites.drm(host).coerceIn(0, 2)].lowercase())
        if (Sites.autoplay(host) == Sites.BLOCK) parts.add("Autoplay blocked")
        if (Sites.crossSite(host) == Sites.BLOCK) parts.add("Cross-site cookies blocked")
        if (Sites.notify(host) != Sites.ASK) parts.add("Notifications " + askWords[Sites.notify(host).coerceIn(0, 2)].lowercase())
        if (Sites.popups(host) != Sites.ASK) parts.add("Pop-ups " + askWords[Sites.popups(host).coerceIn(0, 2)].lowercase().replace("ask", "default"))
        return if (parts.isEmpty()) "Location, camera, microphone, autoplay, protected content and more" else parts.joinToString("  ·  ")
    }

    private fun fillConn(col: LinearLayout, tab: Tab) {
        val prefs = act.prefs
        val secure = tab.url.startsWith("https://", true)
        subHeader(col, "Connection")
        col.addView(infoBlock(
            if (secure) "Connection is secure" else "Connection is not secure",
            if (secure) "Information you send to this site, such as passwords or card numbers, is private."
            else "Others on the network may be able to see what you send to this site. Don't enter passwords or card numbers."
        ))
        col.addView(detail(switchRow("Upgrade connections to HTTPS", "All sites", prefs.httpsOnly) { on ->
            prefs.httpsOnly = on
            Engine.apply(prefs)
        }))
    }

    private fun fillShields(col: LinearLayout, tab: Tab) {
        val prefs = act.prefs
        subHeader(col, "Air Block")
        val total = tab.blocked + SiteBridge.blockedFor(host)
        col.addView(infoBlock("$total blocked on this page", "Requests to known ad and tracker servers were stopped before they loaded."))
        if (Urls.fragile(host)) {
            col.addView(infoBlock("Gentle mode", "This kind of site (video, sign-in, shopping or banking) always uses the lightest blocking so it keeps working."))
        }
        val names = arrayOf("Light", "Standard", "Strong", "Aggressive")
        val list = LinearLayout(act)
        list.orientation = LinearLayout.VERTICAL
        val lvl = prefs.adLevel.coerceIn(0, 3)
        for (i in names.indices) {
            list.addView(optionRow(names[i] + if (i == 1) "  (recommended)" else "", i == lvl) {
                prefs.adLevel = i
                SiteBridge.adLevel = i
                Engine.apply(prefs)
                reload(tab)
                refresh()
            })
        }
        col.addView(sectionLabel("Blocking strength"))
        col.addView(detail(list))
    }

    private fun fillCookies(col: LinearLayout) {
        val prefs = act.prefs
        subHeader(col, "Cookies and site data")
        val mode = prefs.cookieMode.coerceIn(0, cookieNames.size - 1)
        val list = LinearLayout(act)
        list.orientation = LinearLayout.VERTICAL
        for (i in cookieNames.indices) {
            list.addView(optionRow(cookieNames[i], i == mode) {
                prefs.cookieMode = i
                Engine.apply(prefs)
                refresh()
            })
        }
        col.addView(detail(list))
        col.addView(divider().also { (it.layoutParams as LinearLayout.LayoutParams).leftMargin = dp(16) })
        col.addView(detail(switchRow("Block fingerprinting", "All sites", prefs.fingerprint) { on ->
            prefs.fingerprint = on
            Engine.apply(prefs)
        }))
    }

    private fun fillPerms(col: LinearLayout) {
        subHeader(col, "Permissions")
        val loc = Sites.location(host).coerceIn(0, 2)
        val cam = Sites.camera(host).coerceIn(0, 2)
        val mic = Sites.mic(host).coerceIn(0, 2)
        val list = LinearLayout(act)
        list.orientation = LinearLayout.VERTICAL
        list.addView(segRow("Location", null, askWords, loc) { Sites.setLocation(host, it) })
        list.addView(segRow("Camera", null, askWords, cam) { Sites.setCamera(host, it) })
        list.addView(segRow("Microphone", null, askWords, mic) { Sites.setMic(host, it) })
        list.addView(segRow("Protected content", "Netflix-style video and music (DRM)", askWords, Sites.drm(host).coerceIn(0, 2)) { Sites.setDrm(host, it) })
        list.addView(
            segRow("Autoplay with sound", "Pages that start playing sound by themselves", arrayOf("Allow", "Block"),
                if (Sites.autoplay(host) == Sites.BLOCK) 1 else 0) { Sites.setAutoplay(host, if (it == 1) Sites.BLOCK else Sites.ALLOW) }
        )
        list.addView(
            segRow("Cross-site cookies", "Other sites using this site's storage inside a page", arrayOf("Allow", "Block"),
                if (Sites.crossSite(host) == Sites.BLOCK) 1 else 0) { Sites.setCrossSite(host, if (it == 1) Sites.BLOCK else Sites.ALLOW) }
        )
        list.addView(segRow("Notifications", "Messages the site sends while you browse", askWords, Sites.notify(host).coerceIn(0, 2)) { Sites.setNotify(host, it) })
        list.addView(
            segRow("Pop-ups and redirects", "Default follows your Settings", arrayOf("Default", "Allow", "Block"),
                Sites.popups(host).coerceIn(0, 2)) { Sites.setPopups(host, it) }
        )
        col.addView(detail(list))
        col.addView(infoBlock("", "Ask means the site has to ask you each time. Your choice is remembered for this site only. Changes apply the next time the page loads."))
    }

    private fun infoBlock(title: String, body: String): View {
        val b = LinearLayout(act)
        b.orientation = LinearLayout.VERTICAL
        b.pad(20, 12, 18, 6)
        if (title.isNotEmpty()) b.addView(text(act, title, 15.5f, C.INK, true))
        b.addView(text(act, body, 13.5f, subColor), lp(-1, -2).apply { topMargin = if (title.isEmpty()) 0 else dp(3) })
        return b
    }

    private fun sectionLabel(s: String): View {
        val t = text(act, s, 13f, subColor, true)
        t.pad(20, 10, 16, 2)
        return t
    }

    private fun divider(): View {
        val v = View(act)
        v.setBackgroundColor(if (C.dark) 0x33FFFFFF else 0x26000000)
        v.layoutParams = LinearLayout.LayoutParams(-1, maxOf(1, dp(1) / 2)).apply { leftMargin = dp(54) }
        return v
    }

    /** One line of the list: icon, title and a short status, with an optional control or chevron. */
    private fun row(res: Int, title: String, sub: String?, key: String?, trailing: View?): LinearLayout {
        val r = LinearLayout(act)
        r.gravity = Gravity.CENTER_VERTICAL
        r.minimumHeight = dp(62)
        r.pad(16, 8, 14, 8)
        r.background = withRipple(null)
        r.addView(icon(act, res, 22), LinearLayout.LayoutParams(dp(22), dp(22)).apply { rightMargin = dp(18) })
        r.addView(labels(title, sub), LinearLayout.LayoutParams(0, -2, 1f))
        val end: View? = trailing ?: if (key != null) text(act, "›", 22f, subColor) else null
        if (end != null) r.addView(end)
        if (key != null) r.setOnClickListener { go(key, true) }
        return r
    }

    /** The controls that unfold under a row, lined up with its text. */
    private fun detail(inner: View): LinearLayout {
        val d = LinearLayout(act)
        d.orientation = LinearLayout.VERTICAL
        d.pad(56, 0, 14, 8)
        d.addView(inner, LinearLayout.LayoutParams(-1, -2))
        return d
    }

    private fun optionRow(label: String, on: Boolean, pick: () -> Unit): LinearLayout {
        val r = LinearLayout(act)
        r.gravity = Gravity.CENTER_VERTICAL
        r.minimumHeight = dp(44)
        r.background = withRipple(null)
        r.addView(text(act, label, 15f, C.INK, on), LinearLayout.LayoutParams(0, -2, 1f))
        if (on) r.addView(icon(act, R.drawable.ic_check, 18), LinearLayout.LayoutParams(dp(18), dp(18)))
        r.setOnClickListener { pick() }
        return r
    }

    /** Ads and script switches apply to the next load, so the page reloads. */
    /** Deletes everything this site has stored on the device, after asking. */
    private fun shred(tab: Tab) {
        val name = host.removePrefix("www.")
        if (name.isEmpty()) return
        android.app.AlertDialog.Builder(act)
            .setTitle("Shred data for $name?")
            .setMessage("Cookies, local storage and cached files for this site are deleted. You'll be signed out of it.")
            .setPositiveButton("Shred") { _, _ ->
                close()
                try {
                    Engine.runtime.storageController
                        .clearDataFromHost(name, org.mozilla.geckoview.StorageController.ClearFlags.SITE_DATA or org.mozilla.geckoview.StorageController.ClearFlags.ALL_CACHES)
                        .accept({
                            act.runOnUiThread {
                                act.toast("Shredded data for $name")
                                reload(tab)
                            }
                        }, { act.runOnUiThread { act.toast("Couldn't shred the data") } })
                } catch (e: Exception) {
                    act.toast("Couldn't shred the data")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun reload(tab: Tab) {
        try {
            if (!tab.home && tab.session.isOpen) tab.session.reload()
        } catch (e: Exception) {
            // The page picks the change up the next time it opens.
        }
    }

    // ---- small pieces ---------------------------------------------------

    private fun switchView(on: Boolean, change: (Boolean) -> Unit): Switch {
        val sw = Switch(act)
        sw.isChecked = on
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.trackTintList = ColorStateList(states, intArrayOf(C.SKY_C, 0x66808080))
        sw.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, 0xFFF2F2F2.toInt()))
        sw.setOnCheckedChangeListener { _, checked -> change(checked) }
        return sw
    }

    private fun labels(title: String, sub: String?): LinearLayout {
        val l = LinearLayout(act)
        l.orientation = LinearLayout.VERTICAL
        l.addView(text(act, title, 15.5f, C.INK))
        if (sub != null) l.addView(text(act, sub, 12.5f, subColor))
        return l
    }

    private fun switchRow(title: String, sub: String?, on: Boolean, change: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(act)
        row.gravity = Gravity.CENTER_VERTICAL
        row.minimumHeight = dp(50)
        row.addView(labels(title, sub), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(switchView(on, change))
        return row
    }

    /** A name on the left and a three-way button (Ask / Allow / Block) on the right. */
    private fun segRow(title: String, sub: String?, options: Array<String>, start: Int, change: (Int) -> Unit): LinearLayout {
        var value = start.coerceIn(0, options.size - 1)
        val row = LinearLayout(act)
        row.gravity = Gravity.CENTER_VERTICAL
        row.minimumHeight = dp(54)
        row.addView(labels(title, sub), LinearLayout.LayoutParams(0, -2, 1f))
        val track = LinearLayout(act)
        track.background = solid(act, if (C.dark) 0x33FFFFFF else 0x1F000000, 16f)
        track.pad(3, 3, 3, 3)
        val chips = ArrayList<TextView>()
        fun paint() {
            for (i in chips.indices) {
                val sel = i == value
                chips[i].background = if (sel) solid(act, C.SKY_C, 13f) else null
                chips[i].setTextColor(if (sel) Color.WHITE else C.INK)
            }
        }
        for (i in options.indices) {
            val t = text(act, options[i], 13.5f, C.INK, true)
            t.gravity = Gravity.CENTER
            t.pad(11, 0, 11, 0)
            t.setOnClickListener {
                value = i
                paint()
                change(i)
            }
            chips.add(t)
            track.addView(t, LinearLayout.LayoutParams(-2, dp(30)))
        }
        paint()
        row.addView(track, LinearLayout.LayoutParams(-2, -2))
        return row
    }
}
