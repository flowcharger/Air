package com.liquidair.browser

import android.app.AlertDialog
import android.app.Dialog
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import org.json.JSONObject
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors

/**
 * The extensions market.
 *  - Installed: Air's own protection (Air Block and Air Sentinel, each with a switch) and the
 *    extensions you added, which you can switch off or remove.
 *  - Explore: searchable cards from Mozilla's add-ons site, limited to extensions that work on
 *    phones and tablets, sorted by popularity, rating, Mozilla's recommendations or newest.
 * Cards sit in one column on phones and two on tablets.
 */
class ExtensionsPage(private val act: MainActivity) {

    private class Listing(
        val guid: String,
        val name: String,
        val summary: String,
        val icon: String?,
        val users: Long,
        val xpi: String,
        val rating: Double,
        val ratings: Long,
        val url: String,
        val author: String
    )

    private val ui = Handler(Looper.getMainLooper())
    private val net = Executors.newFixedThreadPool(3)
    private val icons = LruCache<String, Bitmap>(120)

    private var tab = 0
    private var query = ""
    private var sort = 1
    private var page = 1
    private var more = false
    private var installed: List<WebExtension> = emptyList()
    private val results = ArrayList<Listing>()
    private var status = ""
    private var token = 0
    private val installing = HashSet<String>()

    private lateinit var body: LinearLayout
    private lateinit var segment: LinearLayout
    private lateinit var tools: LinearLayout
    private lateinit var chips: LinearLayout

    private val controller get() = Engine.runtime.webExtensionController
    private val wide get() = act.resources.configuration.screenWidthDp >= 720
    private val sorts = listOf("Popular", "Recommended", "Top rated", "New")

    // ---- page -----------------------------------------------------------------------------

    fun build(): View {
        ExtensionHost.onChange = { act.runOnUiThread { if (tab == 0 && ::body.isInitialized) drawInstalled() } }
        val root = LinearLayout(act)
        root.orientation = LinearLayout.VERTICAL
        val side = if (act.resources.configuration.screenWidthDp >= 600) 28 else 16

        val head = LinearLayout(act)
        head.orientation = LinearLayout.VERTICAL
        head.pad(side, 18, side, 0)
        head.addView(text(act, "Extensions", 26f, C.INK, true))
        head.addView(
            text(act, "Make Air yours with tools and helpers.", 14f, C.MUTED),
            lp(-2, -2).apply { topMargin = act.dp(2) }
        )
        root.addView(head)

        segment = LinearLayout(act)
        segment.pad(4, 4, 4, 4)
        segment.background = solid(act, C.SOFT, 24f)
        root.addView(segment, lp(-2, -2).apply {
            leftMargin = act.dp(side)
            topMargin = act.dp(14)
            bottomMargin = act.dp(10)
        })

        tools = LinearLayout(act)
        tools.orientation = LinearLayout.VERTICAL
        tools.pad(side, 0, side, 4)
        tools.addView(buildSearch(), lp(-1, act.dp(48)))
        val chipScroll = HorizontalScrollView(act)
        chipScroll.isHorizontalScrollBarEnabled = false
        chips = LinearLayout(act)
        chipScroll.addView(chips)
        tools.addView(chipScroll, lp(-1, -2).apply { topMargin = act.dp(10) })
        root.addView(tools)

        val sv = ScrollView(act)
        sv.isVerticalScrollBarEnabled = false
        val frame = CappedFrame(act, act.dp(980))
        body = LinearLayout(act)
        body.orientation = LinearLayout.VERTICAL
        body.pad(side, 8, side, 48)
        frame.addView(body, FrameLayout.LayoutParams(-1, -2))
        sv.addView(frame, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER_HORIZONTAL))
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        drawSegment()
        drawChips()
        show()
        return root
    }

    private fun drawSegment() {
        if (segment.childCount > 0) {
            (segment.getChildAt(0) as SlideSegment).select(tab, true)
            return
        }
        segment.addView(
            SlideSegment(act, listOf("Installed", "Explore"), tab, C.LINK, C.ON_INK, C.INK, 15f, 24, 38, 20f) { i ->
                val dir = if (i > tab) 1f else -1f
                tab = i
                show()
                body.translationX = dir * act.dpf(36f)
                body.alpha = 0f
                body.animate().translationX(0f).alpha(1f).setDuration(260).start()
            }
        )
    }

    private fun drawChips() {
        chips.removeAllViews()
        for (i in sorts.indices) {
            val on = sort == i
            val t = text(act, sorts[i], 14f, if (on) C.ON_INK else C.INK, on)
            t.pad(16, 8, 16, 8)
            t.background = solid(act, if (on) C.LINK else C.SOFT, 18f)
            t.setOnClickListener {
                if (sort != i) {
                    sort = i
                    drawChips()
                    search()
                }
            }
            chips.addView(t, lp(-2, -2).apply { rightMargin = act.dp(8) })
        }
    }

    private fun buildSearch(): View {
        val box = LinearLayout(act)
        box.gravity = Gravity.CENTER_VERTICAL
        box.background = solid(act, C.SOFT, 24f)
        box.pad(16, 0, 12, 0)
        box.addView(icon(act, R.drawable.ic_search, 20), lp(act.dp(20), act.dp(20)).apply { rightMargin = act.dp(12) })
        val input = EditText(act)
        input.hint = "Search extensions"
        input.setHintTextColor(C.MUTED)
        input.setTextColor(C.INK)
        input.textSize = 16f
        input.background = null
        input.setSingleLine(true)
        input.setText(query)
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(e: Editable?) {
                val q = e?.toString()?.trim() ?: ""
                if (q != query) {
                    query = q
                    searchLater()
                }
            }
        })
        box.addView(input, LinearLayout.LayoutParams(0, act.dp(48), 1f))
        return box
    }

    private fun show() {
        tools.visibility = if (tab == 1) View.VISIBLE else View.GONE
        if (tab == 0) {
            loadInstalled()
        } else {
            loadInstalledQuiet()
            if (results.isEmpty()) search() else drawResults()
        }
    }

    // ---- installed ---------------------------------------------------------------------------

    private fun loadInstalled() {
        drawInstalled()
        loadInstalledQuiet()
    }

    private fun loadInstalledQuiet() {
        try {
            controller.list().accept({ list ->
                installed = (list ?: emptyList()).filter { !it.isBuiltIn }
                    .sortedBy { it.metaData?.name?.lowercase(Locale.US) ?: "" }
                if (tab == 0) drawInstalled() else drawResults()
            }, { })
        } catch (e: Exception) {
            // Keep what is shown.
        }
    }

    private fun drawInstalled() {
        body.removeAllViews()
        body.addView(section("Built in"))
        grid(
            listOf(
                builtIn(
                    R.drawable.ic_shield, "Air Block",
                    "Stops ads and trackers before they load, then hides the empty spaces they leave.",
                    act.prefs.adBlockExt, GradientDrawable.Orientation.TL_BR, C.SKY_C, C.SKY_A
                ) { on ->
                    act.prefs.adBlockExt = on
                    Engine.apply(act.prefs)
                    act.toast(if (on) "Air Block is on" else "Air Block is off")
                },
                builtIn(
                    R.drawable.ic_lock, "Air Sentinel",
                    "Scans downloads, warns about fake addresses and dangerous sites, and refuses permission requests from look-alike or pushy sites.",
                    act.prefs.sentinelExt, GradientDrawable.Orientation.TL_BR, 0xFF2E9E6B.toInt(), 0xFF7FD6A8.toInt()
                ) { on ->
                    act.prefs.sentinelExt = on
                    Engine.apply(act.prefs)
                    act.toast(if (on) "Air Sentinel is on" else "Air Sentinel is off")
                }
            )
        )
        body.addView(section(if (installed.isEmpty()) "Added by you" else "Added by you  ·  " + installed.size))
        if (installed.isEmpty()) {
            body.addView(emptyState(), lp(-1, -2))
        } else {
            grid(installed.map { activeCard(it) })
        }
    }

    private fun builtIn(
        res: Int, name: String, desc: String, on: Boolean,
        dir: GradientDrawable.Orientation, c1: Int, c2: Int, change: (Boolean) -> Unit
    ): View {
        val r = card()
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        val badge = FrameLayout(act)
        badge.background = GradientDrawable(dir, intArrayOf(c1, c2)).apply { cornerRadius = act.dpf(15f) }
        val ic = icon(act, res, 24)
        ic.setColorFilter(Color.WHITE)
        badge.addView(ic, FrameLayout.LayoutParams(act.dp(24), act.dp(24), Gravity.CENTER))
        r.addView(badge, lp(act.dp(50), act.dp(50)).apply { rightMargin = act.dp(14) })

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        val title = LinearLayout(act)
        title.gravity = Gravity.CENTER_VERTICAL
        title.addView(text(act, name, 16.5f, C.INK, true))
        val tag = text(act, "BUILT IN", 10f, C.MUTED, true)
        tag.pad(7, 2, 7, 2)
        tag.background = solid(act, C.SHADE, 8f)
        title.addView(tag, lp(-2, -2).apply { leftMargin = act.dp(8) })
        col.addView(title)
        val d = text(act, desc, 12.5f, C.MUTED)
        d.maxLines = 3
        d.ellipsize = TextUtils.TruncateAt.END
        col.addView(d, lp(-2, -2).apply { topMargin = act.dp(3) })
        val state = text(act, if (on) "On" else "Off", 12f, if (on) C.LINK else C.MUTED, true)
        col.addView(state, lp(-2, -2).apply { topMargin = act.dp(5) })
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))

        val sw = Switch(act)
        sw.isChecked = on
        sw.setOnCheckedChangeListener { _, now ->
            state.text = if (now) "On" else "Off"
            state.setTextColor(if (now) C.LINK else C.MUTED)
            change(now)
        }
        r.addView(sw, lp(-2, -2).apply { leftMargin = act.dp(8) })
        return r
    }

    private fun activeCard(ext: WebExtension): View {
        val md = ext.metaData
        val name = md?.name ?: ext.id
        val r = card()
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        val img = ImageView(act)
        img.background = solid(act, C.SHADE, 14f)
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        img.pad(6, 6, 6, 6)
        r.addView(img, lp(act.dp(50), act.dp(50)).apply { rightMargin = act.dp(14) })
        try {
            md?.icon?.getBitmap(112)?.accept({ b -> if (b != null) img.setImageBitmap(b) }, { })
        } catch (e: Exception) {
            // Plain placeholder.
        }
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.addView(oneLine(text(act, name, 16.5f, C.INK, true)))
        val sub = "Version " + (md?.version ?: "") + (md?.description?.takeIf { it.isNotBlank() }?.let { "  ·  $it" } ?: "")
        val s = text(act, sub, 12.5f, C.MUTED)
        s.maxLines = 2
        s.ellipsize = TextUtils.TruncateAt.END
        col.addView(s, lp(-2, -2).apply { topMargin = act.dp(3) })
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))

        val sw = Switch(act)
        sw.isChecked = md?.enabled ?: true
        sw.setOnCheckedChangeListener { _, on ->
            val result = if (on) controller.enable(ext, WebExtensionController.EnableSource.USER)
            else controller.disable(ext, WebExtensionController.EnableSource.USER)
            result.accept({ loadInstalledQuiet() }, { act.toast("Couldn't change it") })
        }
        if (ExtensionHost.hasButton(ext.id)) {
            val open = text(act, "Open", 13.5f, C.ON_INK, true)
            open.gravity = Gravity.CENTER
            open.pad(14, 8, 14, 8)
            open.background = solid(act, C.INK, 16f)
            open.setOnClickListener { ExtensionHost.press(ext.id) }
            r.addView(open, lp(-2, -2).apply { leftMargin = act.dp(8) })
        }
        r.addView(sw, lp(-2, -2).apply { leftMargin = act.dp(8) })
        val rm = iconButton(act, R.drawable.ic_trash, 40, 40, 20, "Remove")
        rm.setOnClickListener {
            AlertDialog.Builder(act)
                .setTitle("Remove $name?")
                .setMessage("Its data is deleted too.")
                .setPositiveButton("Remove") { _, _ ->
                    controller.uninstall(ext).accept({
                        act.toast("Removed")
                        loadInstalledQuiet()
                    }, { act.toast("Couldn't remove it") })
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        r.addView(rm, lp(act.dp(40), act.dp(40)))
        return r
    }

    private fun emptyState(): View {
        val c = LinearLayout(act)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER_HORIZONTAL
        c.pad(20, 26, 20, 26)
        c.background = solid(act, C.SOFT, 22f)
        val ring = FrameLayout(act)
        ring.background = solid(act, C.MINT, 36f)
        ring.addView(icon(act, R.drawable.ic_extension, 32), FrameLayout.LayoutParams(act.dp(32), act.dp(32), Gravity.CENTER))
        c.addView(ring, lp(act.dp(72), act.dp(72)))
        c.addView(text(act, "Nothing added yet", 18f, C.INK, true), lp(-2, -2).apply { topMargin = act.dp(14) })
        val d = text(act, "Block more, translate, change how pages look and more. Thousands of free extensions are waiting.", 13.5f, C.MUTED)
        d.gravity = Gravity.CENTER
        c.addView(d, lp(-2, -2).apply { topMargin = act.dp(6) })
        val go = text(act, "Explore extensions", 15f, C.ON_INK, true)
        go.pad(24, 11, 24, 11)
        go.background = withRipple(solid(act, C.LINK, 22f), solid(act, Color.WHITE, 22f))
        go.setOnClickListener {
            tab = 1
            drawSegment()
            show()
        }
        c.addView(go, lp(-2, -2).apply { topMargin = act.dp(16) })
        return c
    }

    // ---- explore -----------------------------------------------------------------------------

    private fun searchLater() {
        token++
        val mine = token
        ui.postDelayed({ if (mine == token && tab == 1) search() }, 350)
    }

    private fun search() {
        page = 1
        status = "Loading..."
        results.clear()
        more = false
        drawResults()
        runFetch(true)
    }

    private fun loadMore() {
        page++
        runFetch(false)
    }

    private fun runFetch(fresh: Boolean) {
        val mine = ++token
        val q = query
        val s = sort
        val p = page
        net.execute {
            val out = try {
                fetch(q, s, p)
            } catch (e: Exception) {
                null
            }
            ui.post {
                if (mine != token) return@post
                if (out == null) {
                    if (fresh) results.clear()
                    status = "Couldn't reach the add-ons site. Check your connection."
                    more = false
                } else {
                    if (fresh) results.clear()
                    results.addAll(out)
                    more = out.size >= PAGE_SIZE
                    status = if (results.isEmpty()) "No extensions found." else ""
                }
                if (tab == 1) drawResults()
            }
        }
    }

    private fun fetch(q: String, s: Int, p: Int): List<Listing> {
        // Only extensions that work on Android (phones and tablets).
        var u = "https://addons.mozilla.org/api/v5/addons/search/?app=android&type=extension&lang=en-US" +
            "&page_size=$PAGE_SIZE&page=$p"
        u += when (s) {
            1 -> "&promoted=recommended&sort=users"
            2 -> "&sort=rating"
            3 -> "&sort=updated"
            else -> "&sort=users"
        }
        if (q.isNotEmpty()) u += "&q=" + URLEncoder.encode(q, "UTF-8")
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 7000
        c.readTimeout = 9000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) Air")
        val raw = c.inputStream.bufferedReader().use { it.readText() }
        c.disconnect()
        val arr = JSONObject(raw).optJSONArray("results") ?: return emptyList()
        val out = ArrayList<Listing>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val xpi = o.optJSONObject("current_version")?.optJSONObject("file")?.optString("url") ?: continue
            if (!xpi.startsWith("https://")) continue
            val ratings = o.optJSONObject("ratings")
            val author = o.optJSONArray("authors")?.optJSONObject(0)?.optString("name") ?: ""
            out.add(
                Listing(
                    o.optString("guid"), localized(o.opt("name")), localized(o.opt("summary")),
                    o.optString("icon_url").ifEmpty { null }, o.optLong("average_daily_users"), xpi,
                    ratings?.optDouble("average", 0.0) ?: 0.0, ratings?.optLong("count") ?: 0L,
                    o.optString("url"), author
                )
            )
        }
        return out
    }

    private fun localized(v: Any?): String {
        if (v is String) return v
        if (v is JSONObject) {
            val en = v.optString("en-US")
            if (en.isNotEmpty()) return en
            val keys = v.keys()
            if (keys.hasNext()) return v.optString(keys.next())
        }
        return ""
    }

    private fun drawResults() {
        body.removeAllViews()
        body.addView(
            text(act, "Not every extension works in Air. Recommended ones are the most likely to.", 12.5f, C.MUTED),
            lp(-1, -2).apply { bottomMargin = act.dp(10) }
        )
        if (query.isEmpty() && sort == 1) body.addView(hero(), lp(-1, -2).apply { bottomMargin = act.dp(14) })
        if (status.isNotEmpty()) body.addView(note(status))
        grid(results.map { resultCard(it) })
        if (more && status.isEmpty()) {
            val b = text(act, "Show more", 15f, C.LINK, true)
            b.gravity = Gravity.CENTER
            b.pad(24, 12, 24, 12)
            b.background = withRipple(solid(act, C.SOFT, 22f), solid(act, Color.WHITE, 22f))
            b.setOnClickListener {
                b.text = "Loading..."
                loadMore()
            }
            body.addView(b, lp(-1, -2).apply { topMargin = act.dp(6) })
        }
    }

    private fun hero(): View {
        val h = LinearLayout(act)
        h.orientation = LinearLayout.VERTICAL
        h.pad(22, 20, 22, 20)
        h.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.SKY_C, C.SKY_A)).apply {
            cornerRadius = act.dpf(24f)
        }
        h.addView(text(act, "Recommended by Mozilla", 20f, Color.WHITE, true))
        h.addView(
            text(act, "Each of these is reviewed for safety, quality and privacy.", 13.5f, 0xE6FFFFFF.toInt()),
            lp(-2, -2).apply { topMargin = act.dp(4) }
        )
        return h
    }

    private fun resultCard(l: Listing): View {
        val c = card()
        c.orientation = LinearLayout.VERTICAL
        c.setOnClickListener { detail(l) }

        val top = LinearLayout(act)
        top.gravity = Gravity.CENTER_VERTICAL
        val img = ImageView(act)
        img.background = solid(act, C.SHADE, 14f)
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        img.pad(6, 6, 6, 6)
        top.addView(img, lp(act.dp(52), act.dp(52)).apply { rightMargin = act.dp(14) })
        bindIcon(l.icon, img)
        val names = LinearLayout(act)
        names.orientation = LinearLayout.VERTICAL
        names.addView(oneLine(text(act, l.name, 16.5f, C.INK, true)))
        if (l.author.isNotEmpty()) {
            names.addView(oneLine(text(act, "by " + l.author, 12f, C.MUTED)), lp(-2, -2).apply { topMargin = act.dp(2) })
        }
        top.addView(names, LinearLayout.LayoutParams(0, -2, 1f))
        c.addView(top)

        val s = text(act, l.summary, 13.5f, C.INK)
        s.maxLines = 3
        s.ellipsize = TextUtils.TruncateAt.END
        c.addView(s, lp(-1, -2).apply { topMargin = act.dp(10) })

        val bottom = LinearLayout(act)
        bottom.gravity = Gravity.CENTER_VERTICAL
        bottom.addView(text(act, stats(l), 12f, C.MUTED), LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(addButton(l, false))
        c.addView(bottom, lp(-1, -2).apply { topMargin = act.dp(12) })
        return c
    }

    private fun stats(l: Listing): String {
        val parts = ArrayList<String>()
        if (l.rating > 0) parts.add("★ " + String.format(Locale.US, "%.1f", l.rating) + " (" + compact(l.ratings) + ")")
        parts.add(compact(l.users) + " users")
        return parts.joinToString("  ·  ")
    }

    private fun compact(n: Long): String = when {
        n >= 1_000_000 -> String.format(Locale.US, "%.1fM", n / 1_000_000.0)
        n >= 1000 -> "${n / 1000}K"
        else -> "$n"
    }

    private fun addButton(l: Listing, onSheet: Boolean): TextView {
        val have = installed.any { it.id == l.guid }
        val busy = installing.contains(l.guid)
        val label = if (have) "✓ Installed" else if (busy) "Adding..." else "Add to Air"
        val b = text(act, if (onSheet) label else label.removeSuffix(" to Air"), 14f, if (have || busy) C.MUTED else C.ON_INK, true)
        b.gravity = Gravity.CENTER
        b.pad(18, 9, 18, 9)
        b.background = if (have || busy) solid(act, C.SHADE, 20f)
        else withRipple(solid(act, C.LINK, 20f), solid(act, Color.WHITE, 20f))
        if (!have && !busy) b.setOnClickListener { add(l) }
        return b
    }

    private fun detail(l: Listing) {
        val dlg = Dialog(act)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val card = LinearLayout(act)
        card.orientation = LinearLayout.VERTICAL
        card.pad(22, 22, 22, 18)
        card.background = solid(act, C.WHITE, 28f)
        dlg.setContentView(card)

        val top = LinearLayout(act)
        top.gravity = Gravity.CENTER_VERTICAL
        val img = ImageView(act)
        img.background = solid(act, C.SHADE, 18f)
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        img.pad(8, 8, 8, 8)
        top.addView(img, lp(act.dp(68), act.dp(68)).apply { rightMargin = act.dp(16) })
        bindIcon(l.icon, img)
        val names = LinearLayout(act)
        names.orientation = LinearLayout.VERTICAL
        val n = text(act, l.name, 20f, C.INK, true)
        n.maxLines = 2
        n.ellipsize = TextUtils.TruncateAt.END
        names.addView(n)
        if (l.author.isNotEmpty()) names.addView(text(act, "by " + l.author, 13f, C.MUTED), lp(-2, -2).apply { topMargin = act.dp(2) })
        top.addView(names, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(top)

        card.addView(text(act, stats(l), 13f, C.LINK, true), lp(-2, -2).apply { topMargin = act.dp(14) })
        val sv = ScrollView(act)
        sv.addView(text(act, l.summary.ifEmpty { "No description." }, 14.5f, C.INK))
        card.addView(sv, lp(-1, -2).apply { topMargin = act.dp(10) })
        card.addView(
            text(act, "Extensions can see the pages you visit. You'll see what this one asks for before it's added.", 12f, C.MUTED),
            lp(-1, -2).apply { topMargin = act.dp(12) }
        )

        val row = LinearLayout(act)
        row.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        if (l.url.startsWith("https://")) {
            val site = text(act, "View on Mozilla", 14f, C.LINK, true)
            site.pad(14, 10, 14, 10)
            site.background = withRipple(null)
            site.setOnClickListener {
                dlg.dismiss()
                act.openLink(l.url)
            }
            row.addView(site)
        }
        val addBtn = addButton(l, true)
        if (!installed.any { it.id == l.guid } && !installing.contains(l.guid)) {
            addBtn.setOnClickListener {
                dlg.dismiss()
                add(l)
            }
        }
        row.addView(addBtn, lp(-2, -2).apply { leftMargin = act.dp(6) })
        card.addView(row, lp(-1, -2).apply { topMargin = act.dp(16) })

        val w = dlg.window
        w?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        w?.setDimAmount(0.45f)
        dlg.show()
        val px = act.resources.displayMetrics.widthPixels
        w?.setLayout(if (wide) act.dp(460) else (px * 0.92f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        w?.setGravity(if (wide) Gravity.CENTER else Gravity.BOTTOM)
        if (!wide) w?.attributes = w?.attributes?.also { it.y = act.dp(14) }
    }

    private fun add(l: Listing) {
        installing.add(l.guid)
        drawResults()
        try {
            controller.install(l.xpi).accept({ ext ->
                installing.remove(l.guid)
                if (ext != null) ExtensionHost.attach(ext)
                act.toast("Added " + (ext?.metaData?.name ?: l.name))
                loadInstalledQuiet()
            }, {
                installing.remove(l.guid)
                act.toast("Not added")
                if (tab == 1) drawResults()
            })
        } catch (e: Exception) {
            installing.remove(l.guid)
            act.toast("Couldn't add it")
            drawResults()
        }
    }

    // ---- pieces -----------------------------------------------------------------------------

    /** One column on phones, two on tablets. */
    private fun grid(views: List<View>) {
        if (!wide) {
            for (v in views) body.addView(v, lp(-1, -2).apply { bottomMargin = act.dp(10) })
            return
        }
        var i = 0
        while (i < views.size) {
            val row = LinearLayout(act)
            row.isBaselineAligned = false
            row.addView(views[i], LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = act.dp(5) })
            if (i + 1 < views.size) {
                row.addView(views[i + 1], LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = act.dp(5) })
            } else {
                row.addView(View(act), LinearLayout.LayoutParams(0, 0, 1f).apply { leftMargin = act.dp(5) })
            }
            body.addView(row, lp(-1, -2).apply { bottomMargin = act.dp(10) })
            i += 2
        }
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(act)
        c.pad(16, 16, 16, 16)
        c.background = withRipple(solid(act, C.SOFT, 22f), solid(act, Color.WHITE, 22f))
        return c
    }

    private fun section(s: String): TextView {
        val t = text(act, s.uppercase(Locale.US), 12f, C.MUTED, true)
        t.letterSpacing = 0.08f
        t.pad(4, 10, 4, 10)
        return t
    }

    private fun note(s: String): TextView {
        val t = text(act, s, 14f, C.MUTED)
        t.pad(6, 14, 6, 14)
        return t
    }

    private fun bindIcon(url: String?, into: ImageView) {
        if (url == null) return
        val cached = icons.get(url)
        if (cached != null) {
            into.setImageBitmap(cached)
            return
        }
        into.tag = url
        net.execute {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 4000
                c.readTimeout = 4000
                val bmp = c.inputStream.use { BitmapFactory.decodeStream(it) }
                c.disconnect()
                if (bmp != null) {
                    icons.put(url, bmp)
                    ui.post { if (into.tag == url) into.setImageBitmap(bmp) }
                }
            } catch (e: Exception) {
                // Placeholder stays.
            }
        }
    }

    private companion object {
        const val PAGE_SIZE = 24
    }
}
