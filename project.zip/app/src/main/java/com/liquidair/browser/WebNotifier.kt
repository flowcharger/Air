package com.liquidair.browser

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import org.mozilla.geckoview.WebNotification
import org.mozilla.geckoview.WebNotificationDelegate

/**
 * Shows notifications that websites send (once you have allowed the site) as ordinary Android
 * notifications, and opens the page when one is tapped. Private tabs never show any.
 */
object WebNotifier : WebNotificationDelegate {
    const val EXTRA = "webNotif"
    private const val CHANNEL = "web_notifications"

    private lateinit var app: Context
    private val live = HashMap<String, WebNotification>()
    private val main = Handler(Looper.getMainLooper())

    fun install(act: MainActivity) {
        app = act.applicationContext
        val nm = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Website notifications", NotificationManager.IMPORTANCE_DEFAULT))
        Engine.runtime.webNotificationDelegate = this
    }

    override fun onShowNotification(notification: WebNotification) {
        main.post {
            try {
                if (notification.privateBrowsing) return@post
                val host = Urls.hostOf(notification.source ?: "")
                if (Sites.notify(host) == Sites.BLOCK) return@post
                if (app.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) return@post
                val id = notification.tag
                live[id] = notification
                val open = Intent(app, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra(EXTRA, id)
                val pi = PendingIntent.getActivity(
                    app, id.hashCode(), open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                val n = Notification.Builder(app, CHANNEL)
                    .setSmallIcon(R.drawable.ic_bell)
                    .setContentTitle(notification.title ?: host.removePrefix("www."))
                    .setContentText(notification.text ?: "")
                    .setSubText(host.removePrefix("www."))
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build()
                (app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id.hashCode(), n)
            } catch (e: Exception) {
                // A notification that can't be shown is dropped.
            }
        }
    }

    override fun onCloseNotification(notification: WebNotification) {
        main.post {
            live.remove(notification.tag)
            try {
                (app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(notification.tag.hashCode())
            } catch (e: Exception) {
            }
        }
    }

    /** The person tapped one: tell the page, which usually focuses or opens itself. */
    fun click(id: String) {
        try {
            live[id]?.click()
        } catch (e: Exception) {
        }
    }
}
