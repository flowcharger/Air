package com.liquidair.browser

import android.content.Context
import android.net.Uri
import java.util.Locale

/**
 * Air Sentinel: looks at every finished download and warns about files that are likely to hurt.
 *
 * It is a set of checks, not a signature engine like a desktop anti-virus: it recognises the
 * standard anti-virus test file, programs pretending to be pictures or documents, double
 * extensions, and file types that can run code. It cannot spot every new malware, so keep
 * "Warn about dangerous sites" on too.
 */
object Antivirus {
    class Verdict(val danger: Boolean, val reasons: List<String>) {
        val clean get() = reasons.isEmpty()
    }

    private val PROGRAM = setOf(
        "apk", "xapk", "apks", "exe", "msi", "bat", "cmd", "scr", "com", "pif", "vbs", "vbe", "js", "jse",
        "wsf", "ps1", "hta", "jar", "lnk", "sh", "dll", "reg", "dmg"
    )
    private val MACRO = setOf("docm", "xlsm", "pptm", "dotm", "xlam")
    private val PLAIN = setOf(
        "pdf", "jpg", "jpeg", "png", "gif", "webp", "bmp", "mp3", "mp4", "m4a", "mkv", "avi", "mov", "wav",
        "txt", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "csv", "rtf"
    )
    private val DOUBLE = Regex(
        "\\.(pdf|docx?|xlsx?|pptx?|jpe?g|png|gif|txt|mp3|mp4)\\.(exe|apk|bat|cmd|scr|com|js|vbs|ps1|jar|lnk|sh|hta)$",
        RegexOption.IGNORE_CASE
    )

    // ---- addresses ----------------------------------------------------------------------------

    private val BRANDS = listOf(
        "paypal", "google", "facebook", "instagram", "apple", "icloud", "microsoft", "outlook", "amazon",
        "netflix", "whatsapp", "binance", "coinbase", "steam", "discord", "dropbox", "linkedin", "telegram"
    )
    private val SECOND_LEVEL = setOf("co", "com", "org", "net", "gov", "edu", "ac")
    private val SHARED = setOf(
        "blogspot.com", "github.io", "herokuapp.com", "netlify.app", "vercel.app", "pages.dev", "web.app",
        "firebaseapp.com", "azurewebsites.net", "cloudfront.net", "amazonaws.com", "myshopify.com", "wordpress.com"
    )

    /** Hosts the user chose to open anyway, for this run of the app. */
    val allowed = HashSet<String>()

    /**
     * Looks for the two address tricks that fake sites use most: a name before an @ sign that
     * hides the real site (https://google.com@evil.example), and a famous brand placed in the
     * front of a different site (paypal.com.evil.example). Returns why it looks wrong, or null.
     */
    fun suspiciousAddress(url: String): String? {
        if (!(url.startsWith("http://", true) || url.startsWith("https://", true))) return null
        val authority = url.substringAfter("://").substringBefore('/').substringBefore('?').substringBefore('#')
        if (authority.contains('@')) {
            return "The address puts a name before an @ sign to hide where it really goes. The real site is " +
                authority.substringAfterLast('@').substringBefore(':') + "."
        }
        val host = authority.substringBefore(':').lowercase(Locale.US).trimEnd('.')
        val parts = host.split('.')
        if (parts.size < 3) return null
        val regCount = if (parts.last().length == 2 && parts[parts.size - 2] in SECOND_LEVEL) 3 else 2
        if (parts.size <= regCount) return null
        val registrable = parts.takeLast(regCount).joinToString(".")
        if (SHARED.any { registrable == it }) return null
        val regName = parts[parts.size - regCount]
        val subs = parts.dropLast(regCount)
        for (b in BRANDS) {
            if (regName.contains(b)) return null
        }
        for (label in subs) {
            for (b in BRANDS) {
                if (label == b || label.startsWith("$b-") || label.endsWith("-$b")) {
                    return "This address starts with \"$b\" but it belongs to $registrable, not to $b."
                }
            }
        }
        return null
    }

    /** Reads the start of the file and returns what it really is, or null if it looks ordinary. */
    private fun realKind(head: ByteArray, n: Int): String? {
        fun at(i: Int) = if (i < n) head[i].toInt() and 0xFF else -1
        if (at(0) == 'M'.code && at(1) == 'Z'.code) return "Windows program"
        if (at(0) == 0x7F && at(1) == 'E'.code && at(2) == 'L'.code && at(3) == 'F'.code) return "Linux/Android program"
        if (at(0) == 'd'.code && at(1) == 'e'.code && at(2) == 'x'.code && at(3) == 0x0A) return "Android code file"
        if (at(0) == '#'.code && at(1) == '!'.code) return "script"
        if (at(0) == 'P'.code && at(1) == 'K'.code && at(2) == 3 && at(3) == 4) {
            val s = String(head, 0, n, Charsets.ISO_8859_1)
            if (s.contains("AndroidManifest.xml") || s.contains("classes.dex")) return "Android app"
        }
        return null
    }

    fun scan(ctx: Context, uri: Uri?, name: String, url: String): Verdict {
        val reasons = ArrayList<String>()
        var danger = false
        val ext = name.substringAfterLast('.', "").lowercase(Locale.US)
        var head = ByteArray(4096)
        var n = 0
        try {
            if (uri != null) {
                ctx.contentResolver.openInputStream(uri)?.use { input ->
                    n = input.read(head).coerceAtLeast(0)
                }
            }
        } catch (e: Exception) {
            n = 0
        }

        if (n > 0 && String(head, 0, n, Charsets.ISO_8859_1).contains("EICAR-STANDARD-ANTIVIRUS-TEST-FILE")) {
            reasons.add("It is the standard anti-virus test file (EICAR). It is harmless, but it proves the scanner works.")
            danger = true
        }

        val real = if (n > 0) realKind(head, n) else null
        if (real != null && ext in PLAIN) {
            reasons.add("It is named .$ext but is really a $real. This is a common way to hide a virus.")
            danger = true
        }
        if (DOUBLE.containsMatchIn(name)) {
            reasons.add("It has a double extension, which is used to make a program look like a document or picture.")
            danger = true
        }
        if (ext in PROGRAM) {
            val kind = if (ext == "apk" || ext == "xapk" || ext == "apks") "An Android app from outside the Play Store"
            else "A program or script"
            reasons.add("$kind can run code on your device. Only keep it if you trust the site.")
            if (url.startsWith("http://")) {
                reasons.add("It was downloaded over an insecure connection, so it could have been changed on the way.")
                danger = true
            }
        } else if (real != null && ext !in PLAIN) {
            reasons.add("It looks like a $real. Only keep it if you trust the site.")
        }
        if (ext in MACRO) reasons.add("It is an Office file that can contain macros. Macros can run harmful code.")
        return Verdict(danger, reasons)
    }
}
