package com.liquidair.browser

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import org.mozilla.geckoview.WebExtension

/** The sheet shown before an extension is added: who it is, what it can do, and a clear Add / Cancel. */
object ExtensionPrompt {

    private class Line(val text: String, val strong: Boolean)

    fun show(
        act: MainActivity,
        ext: WebExtension,
        permissions: Array<String>,
        origins: Array<String>,
        data: Array<String>,
        answer: (Boolean) -> Unit
    ) {
        val lines = ArrayList<Line>()
        val allSites = origins.any { it.contains("all_urls") || it == "*://*/*" || it == "<all_urls>" || (it.startsWith("*://*.") && it.length < 12) }
        if (allSites) lines.add(Line("Read and change your data on every website you visit", true))
        else if (origins.isNotEmpty()) lines.add(Line("Read and change your data on " + origins.size + " site" + (if (origins.size == 1) "" else "s"), false))
        for (p in permissions) {
            when (p) {
                "tabs" -> lines.add(Line("See the pages you have open", true))
                "cookies" -> lines.add(Line("Read and change cookies", true))
                "webRequest", "webRequestBlocking" -> lines.add(Line("Watch and block network requests", true))
                "downloads" -> lines.add(Line("Manage downloads", false))
                "history" -> lines.add(Line("Read your browsing history", true))
                "bookmarks" -> lines.add(Line("Read and change your bookmarks", false))
                "clipboardRead" -> lines.add(Line("Read what you copied", true))
                "clipboardWrite" -> lines.add(Line("Copy to the clipboard", false))
                "geolocation" -> lines.add(Line("Know your location", true))
                "nativeMessaging" -> lines.add(Line("Talk to other apps on this device", true))
                "notifications" -> lines.add(Line("Show notifications", false))
                "privacy" -> lines.add(Line("Change privacy settings", true))
                "proxy" -> lines.add(Line("Control how you connect to the internet", true))
                "storage", "unlimitedStorage" -> lines.add(Line("Keep its own settings and data", false))
                "contextMenus", "menus" -> lines.add(Line("Add items to page menus", false))
                "alarms", "activeTab", "scripting" -> {}
            }
        }
        if (data.isNotEmpty()) lines.add(Line("Collect or share data about you (see the add-on page)", true))
        val distinct = lines.distinctBy { it.text }

        val dlg = Dialog(act)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        var decided = false
        fun finish(v: Boolean) {
            if (decided) return
            decided = true
            answer(v)
        }

        val card = LinearLayout(act)
        card.orientation = LinearLayout.VERTICAL
        card.pad(24, 24, 24, 18)
        card.background = solid(act, C.WHITE, 30f)
        dlg.setContentView(card)

        val head = LinearLayout(act)
        head.gravity = Gravity.CENTER_VERTICAL
        val img = ImageView(act)
        img.background = solid(act, C.SHADE, 18f)
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        img.pad(8, 8, 8, 8)
        head.addView(img, lp(act.dp(64), act.dp(64)).apply { rightMargin = act.dp(16) })
        try {
            ext.metaData?.icon?.getBitmap(128)?.accept({ b -> if (b != null) img.setImageBitmap(b) }, { })
        } catch (e: Exception) {
            // Plain placeholder.
        }
        val names = LinearLayout(act)
        names.orientation = LinearLayout.VERTICAL
        names.addView(text(act, "Add " + (ext.metaData?.name ?: "this extension") + "?", 19f, C.INK, true))
        names.addView(
            text(act, "Version " + (ext.metaData?.version ?: ""), 12.5f, C.MUTED),
            lp(-2, -2).apply { topMargin = act.dp(3) }
        )
        head.addView(names, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(head)

        val broad = distinct.any { it.strong }
        val chip = text(
            act,
            if (distinct.isEmpty()) "Needs no special access" else if (broad) "Asks for broad access" else "Asks for limited access",
            12.5f, if (broad) 0xFF9A5B00.toInt() else 0xFF1F7A4D.toInt(), true
        )
        chip.pad(12, 6, 12, 6)
        chip.background = solid(act, if (broad) 0x33FFB020 else 0x3330C080, 14f)
        card.addView(chip, lp(-2, -2).apply { topMargin = act.dp(16) })

        if (distinct.isNotEmpty()) {
            card.addView(text(act, "It will be able to", 13f, C.MUTED, true), lp(-2, -2).apply { topMargin = act.dp(16) })
            val list = LinearLayout(act)
            list.orientation = LinearLayout.VERTICAL
            for (l in distinct) {
                val row = LinearLayout(act)
                row.gravity = Gravity.CENTER_VERTICAL
                row.pad(0, 7, 0, 7)
                val dot = View(act)
                dot.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (l.strong) 0xFFE59A1A.toInt() else 0xFF2E9E6B.toInt())
                }
                row.addView(dot, lp(act.dp(9), act.dp(9)).apply { rightMargin = act.dp(12) })
                row.addView(text(act, l.text, 14.5f, C.INK), LinearLayout.LayoutParams(0, -2, 1f))
                list.addView(row)
            }
            val sv = ScrollView(act)
            sv.addView(list)
            card.addView(sv, lp(-1, -2).apply { topMargin = act.dp(4) })
        }
        card.addView(
            text(act, "Only add extensions you trust. You can remove or switch it off any time in Extensions.", 12f, C.MUTED),
            lp(-1, -2).apply { topMargin = act.dp(14) }
        )

        val buttons = LinearLayout(act)
        buttons.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        val cancel = text(act, "Cancel", 15f, C.LINK, true)
        cancel.pad(18, 11, 18, 11)
        cancel.background = withRipple(null)
        cancel.setOnClickListener {
            finish(false)
            dlg.dismiss()
        }
        buttons.addView(cancel)
        val add = text(act, "Add extension", 15f, C.ON_INK, true)
        add.pad(22, 11, 22, 11)
        add.background = withRipple(solid(act, C.LINK, 22f), solid(act, Color.WHITE, 22f))
        add.setOnClickListener {
            finish(true)
            dlg.dismiss()
        }
        buttons.addView(add, lp(-2, -2).apply { leftMargin = act.dp(8) })
        card.addView(buttons, lp(-1, -2).apply { topMargin = act.dp(16) })

        dlg.setOnCancelListener { finish(false) }
        dlg.setOnDismissListener { finish(false) }
        val w = dlg.window
        w?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        w?.setDimAmount(0.5f)
        dlg.show()
        val px = act.resources.displayMetrics.widthPixels
        val wide = act.resources.configuration.screenWidthDp >= 600
        w?.setLayout(if (wide) act.dp(480) else (px * 0.92f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }
}
