package com.liquidair.browser

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.view.Window
import android.widget.FrameLayout
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.WebExtension

/**
 * Lets extensions that have a toolbar button (with a pop-up) work: the button's pop-up opens in a
 * sheet. Extensions that only run inside pages need none of this.
 */
object ExtensionHost {
    private var act: MainActivity? = null
    private val actions = HashMap<String, WebExtension.Action>()

    /** Called when an extension's button appears or changes, so the Extensions page can redraw. */
    @Volatile
    var onChange: (() -> Unit)? = null

    fun init(a: MainActivity) {
        act = a
        try {
            Engine.runtime.webExtensionController.list().accept({ list ->
                for (e in list ?: emptyList()) attach(e)
            }, { })
        } catch (e: Exception) {
            // Extensions simply have no pop-ups.
        }
    }

    fun attach(ext: WebExtension) {
        if (ext.isBuiltIn) return
        try {
            ext.setActionDelegate(object : WebExtension.ActionDelegate {
                override fun onBrowserAction(extension: WebExtension, session: GeckoSession?, action: WebExtension.Action) {
                    if (session == null) {
                        actions[extension.id] = action
                        onChange?.invoke()
                    }
                }

                override fun onTogglePopup(extension: WebExtension, action: WebExtension.Action): GeckoResult<GeckoSession>? =
                    popup(extension)
            })
        } catch (e: Exception) {
            // No button for this one.
        }
    }

    fun hasButton(id: String): Boolean = actions[id]?.let { it.enabled != false } ?: false

    /** Presses the extension's toolbar button; its pop-up (if it has one) opens in a sheet. */
    fun press(id: String) {
        try {
            actions[id]?.click()
        } catch (e: Exception) {
            act?.toast("Couldn't open it")
        }
    }

    private fun popup(ext: WebExtension): GeckoResult<GeckoSession>? {
        val a = act ?: return null
        return try {
            val session = GeckoSession()
            session.open(Engine.runtime)
            val view = GeckoView(a)
            view.setSession(session)
            val dlg = Dialog(a)
            dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
            val frame = FrameLayout(a)
            frame.background = solid(a, C.WHITE, 22f)
            frame.clipToOutline = true
            frame.pad(2, 2, 2, 2)
            frame.addView(view, FrameLayout.LayoutParams(-1, -1))
            dlg.setContentView(frame)
            dlg.setOnDismissListener {
                try {
                    view.releaseSession()
                    session.close()
                } catch (e: Exception) {
                    // Already gone.
                }
            }
            val w = dlg.window
            w?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w?.setDimAmount(0.4f)
            dlg.show()
            val dm = a.resources.displayMetrics
            val wide = a.resources.configuration.screenWidthDp >= 600
            w?.setLayout(if (wide) a.dp(400) else (dm.widthPixels * 0.94f).toInt(), (dm.heightPixels * 0.72f).toInt())
            w?.setGravity(Gravity.CENTER)
            GeckoResult.fromValue(session)
        } catch (e: Exception) {
            null
        }
    }
}
