package com.liquidair.browser

import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors

/**
 * The list that drops down under the address bar while you type: search for what you typed, ask
 * Perplexity, open the Wikipedia page, matching bookmarks and history, and (only if switched on in
 * Settings) suggestions from your search engine.
 *
 * Perplexity is opened in a normal tab with your own account; nothing is sent anywhere until you
 * tap a row. Engine suggestions are the only thing sent while typing, and only when you turn
 * them on (and never in private tabs).
 */
class Suggestions(
    private val act: MainActivity,
    private val open: (String) -> Unit
) {
    /** The card to add to the page area. */
    val view = LinearLayout(act)

    private val ui = Handler(Looper.getMainLooper())
    private val net = Executors.newSingleThreadExecutor()
    private var typed = ""
    private var remote: List<String> = emptyList()
    private var token = 0
    private var shownOnce = false

    val isShowing get() = view.visibility == View.VISIBLE

    init {
        view.orientation = LinearLayout.VERTICAL
        view.background = solid(act, C.WHITE, 16f)
        view.elevation = act.dpf(8f)
        view.clipToOutline = true
        view.visibility = View.GONE
        view.isClickable = true
    }

    /** Call with the text in the address bar each time the person changes it. */
    fun update(text: String) {
        val q = text.trim()
        if (q.isEmpty()) {
            hide()
            return
        }
        typed = q
        remote = emptyList()
        draw()
        fetchRemote(q)
    }

    fun hide() {
        token++
        ui.removeCallbacksAndMessages(null)
        shownOnce = false
        view.animate().cancel()
        view.visibility = View.GONE
    }

    // ---- rows ----------------------------------------------------------------

    private fun looksLikeUrl(q: String) =
        !q.contains(' ') && (q.contains('.') || q.startsWith("http", true) || q.startsWith("localhost", true))

    private fun draw() {
        val q = typed
        view.removeAllViews()
        val urlLike = looksLikeUrl(q)
        val engine = Engines.name(act.prefs.searchEngine, act.prefs.customEngine)
        val enc = URLEncoder.encode(q, "UTF-8")

        if (urlLike) {
            addRow(R.drawable.ic_globe, q, "Go to this address") { open(q) }
        } else {
            addRow(R.drawable.ic_search, q, "Search with $engine") { open(q) }
            addRow(R.drawable.ic_sparkle, q, "Ask Perplexity") { open("https://www.perplexity.ai/search?q=$enc") }
            addRow(R.drawable.ic_globe, q, "Open Wikipedia page") {
                open("https://en.wikipedia.org/wiki/Special:Search?search=$enc&go=Go")
            }
        }

        // Bookmarks and history that match (kept on the device).
        val low = q.lowercase(Locale.US)
        val seen = HashSet<String>()
        var shown = 0
        fun local(list: List<Saved>, res: Int, label: String) {
            for (s in list) {
                if (shown >= 4) return
                if (s.url.isEmpty() || !seen.add(s.url)) continue
                val hay = (s.title + " " + s.url).lowercase(Locale.US)
                if (!hay.contains(low)) continue
                addRow(res, s.title.ifEmpty { Urls.display(s.url) }, label + "  ·  " + Urls.display(s.url)) { open(s.url) }
                shown++
            }
        }
        // With suggestions off, only the search, Perplexity and Wikipedia rows show.
        if (act.prefs.suggestions) {
            local(act.browser.bookmarks, R.drawable.ic_star, "Bookmark")
            local(act.browser.history, R.drawable.ic_history, "History")
        }

        // Suggestions from the search engine (only when switched on).
        for (r in remote.take(5)) {
            if (r.equals(q, true)) continue
            addRow(R.drawable.ic_search, r, null) { open(r) }
        }

        if (!shownOnce) {
            shownOnce = true
            view.visibility = View.VISIBLE
            view.pivotY = 0f
            view.arrive(0f, -6f, .98f, Motion.QUICK + 40)
        }
    }

    private fun addRow(res: Int, title: String, sub: String?, onClick: () -> Unit) {
        val r = LinearLayout(act)
        r.gravity = Gravity.CENTER_VERTICAL
        r.minimumHeight = act.dp(54)
        r.pad(16, 6, 14, 6)
        r.background = withRipple(null)
        r.addView(icon(act, res, 20), LinearLayout.LayoutParams(act.dp(20), act.dp(20)).apply { rightMargin = act.dp(16) })
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.addView(oneLine(text(act, title, 15.5f, C.INK)))
        if (sub != null) col.addView(oneLine(text(act, sub, 12.5f, C.MUTED)))
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        r.setOnClickListener {
            hide()
            onClick()
        }
        view.addView(r, LinearLayout.LayoutParams(-1, -2))
    }

    // ---- engine suggestions -----------------------------------------------------

    private fun fetchRemote(q: String) {
        val prefs = act.prefs
        if (!prefs.suggestions || act.browser.privateMode || looksLikeUrl(q)) return
        if (Engines.suggestUrl(prefs.searchEngine, q) == null) return
        val mine = ++token
        ui.removeCallbacksAndMessages(null)
        ui.postDelayed({
            net.execute {
                val out = try {
                    val u = Engines.suggestUrl(prefs.searchEngine, q) ?: return@execute
                    val c = URL(u).openConnection() as HttpURLConnection
                    c.connectTimeout = 2500
                    c.readTimeout = 2500
                    c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) Air")
                    val body = c.inputStream.bufferedReader().use { it.readText().take(16000) }
                    c.disconnect()
                    val arr = JSONArray(body).optJSONArray(1)
                    val list = ArrayList<String>()
                    if (arr != null) for (i in 0 until arr.length()) list.add(arr.optString(i))
                    list
                } catch (e: Exception) {
                    ArrayList<String>()
                }
                ui.post {
                    if (mine == token && typed == q && view.visibility == View.VISIBLE) {
                        remote = out.filter { it.isNotBlank() }
                        draw()
                    }
                }
            }
        }, 180)
    }
}
