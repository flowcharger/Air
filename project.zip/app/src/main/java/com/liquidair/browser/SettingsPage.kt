package com.liquidair.browser

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.util.Locale

/**
 * Settings, laid out like Chrome and Brave: a list of sections down the left side and the
 * chosen section on the right. On a narrow phone the sections become a row of chips on top.
 */
class SettingsPage(private val act: MainActivity) {

    private class Section(val key: String, val label: String, val icon: Int)

    private val sections = listOf(
        Section("general", "General", R.drawable.ic_tune),
        Section("themes", "Themes", R.drawable.ic_palette),
        Section("news", "News", R.drawable.ic_newtab),
        Section("privacy", "Privacy and security", R.drawable.ic_shield),
        Section("memory", "Memory", R.drawable.ic_memory),
        Section("passwords", "Passwords", R.drawable.ic_key),
        Section("downloads", "Downloads", R.drawable.ic_download),
        Section("data", "Import and export", R.drawable.ic_swap),
        Section("about", "About", R.drawable.ic_info)
    )

    private var wide = true
    private var navHost: LinearLayout? = null
    private var body: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var shownSection = ""
    private var passwordQuery = ""
    private var query = ""

    /** Everything you can search for: title, what it does, and the section it lives in. */
    private class Entry(val title: String, val about: String, val section: String)

    private val index = listOf(
        Entry("Search engine", "google brave duckduckgo default search", "general"),
        Entry("News on the start page", "news channels feed headlines bbc al jazeera guardian verge", "news"),
        Entry("Search engine custom", "bing startpage ecosia qwant yahoo yandex mojeek perplexity wikipedia", "general"),
        Entry("Search suggestions", "autocomplete address bar suggestions typing", "general"),
        Entry("SafeSearch", "adult content filter google", "general"),
        Entry("Start page overview", "wikipedia perplexity ai overview home", "general"),
        Entry("Restore tabs", "startup open pages last time", "general"),
        Entry("Request desktop site", "desktop mode computer", "general"),
        Entry("Background play", "sound screen off music video audio", "general"),
        Entry("Compatibility video decoding", "youtube black blurry zoomed video decoder software", "general"),
        Entry("Battery settings", "battery optimisation keep running", "general"),
        Entry("Start page background", "wallpaper picture image custom upload fit fill stretch cut off dim darken", "themes"),
        Entry("Picture fit", "background upload cropped cut off fit fill stretch center", "themes"),
        Entry("Theme", "light dark system appearance", "themes"),
        Entry("Page zoom", "text size bigger smaller font", "themes"),
        Entry("Cookies", "block third-party cross-site tracking cookies", "privacy"),
        Entry("Clear browsing data", "history cache cookies delete", "privacy"),
        Entry("Clear data on exit", "forget cookies site data", "privacy"),
        Entry("Air Block", "air block ads trackers adblock shields blocker", "privacy"),
        Entry("Air Block strength", "air block blocking strength ad blocker aggression level light standard strong aggressive", "privacy"),
        Entry("Air Sentinel", "air sentinel antivirus anti-virus malware phishing scan downloads protection", "privacy"),
        Entry("Warn about dangerous sites", "safe browsing phishing malware", "privacy"),
        Entry("HTTPS-only mode", "secure connection https", "privacy"),
        Entry("Block pop-ups", "redirects popups windows", "privacy"),
        Entry("Stop pages opening other apps", "external app intents", "privacy"),
        Entry("Remove tracking from links", "utm fbclid gclid", "privacy"),
        Entry("Fingerprinting protection", "fingerprint identify device", "privacy"),
        Entry("Warn before risky downloads", "apk exe scripts", "privacy"),
        Entry("Global Privacy Control", "gpc do not sell", "privacy"),
        Entry("Site permissions", "location camera microphone ask", "privacy"),
        Entry("Limit memory use", "ram memory limit sleep tabs", "memory"),
        Entry("Free memory now", "ram clear caches background tabs", "memory"),
        Entry("Saved passwords", "logins vault password manager", "passwords"),
        Entry("Offer to save passwords", "autofill login", "passwords"),
        Entry("Downloads", "files download list storage", "downloads"),
        Entry("Import bookmarks", "chrome brave firefox html", "data"),
        Entry("Export bookmarks", "backup html", "data"),
        Entry("Import and export passwords", "csv chrome brave migrate", "data"),
        Entry("Import history", "browser data transfer", "data"),
        Entry("About Air", "version licence open source", "about")
    )

    private val prefs get() = act.prefs

    private fun dp(v: Int) = act.dp(v)

    // ---- frame: sections on the left, content on the right ---------------------------------

    fun build(): View {
        wide = act.resources.configuration.screenWidthDp >= 600
        val root = LinearLayout(act)
        root.orientation = if (wide) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL

        val nav = LinearLayout(act)
        navHost = nav
        if (wide) {
            nav.orientation = LinearLayout.VERTICAL
            nav.pad(12, 8, 12, 16)
            val navCol = LinearLayout(act)
            navCol.orientation = LinearLayout.VERTICAL
            navCol.addView(searchBox(), lp(-1, -2))
            navCol.addView(nav, lp(-1, -2))
            val navScroll = ScrollView(act)
            navScroll.addView(navCol, FrameLayout.LayoutParams(-1, -2))
            root.addView(navScroll, LinearLayout.LayoutParams(dp(264), -1))
            val divider = View(act)
            divider.setBackgroundColor(C.LINE)
            root.addView(divider, LinearLayout.LayoutParams(maxOf(1, dp(1)), -1))
        } else {
            nav.orientation = LinearLayout.HORIZONTAL
            nav.pad(12, 4, 12, 8)
            root.addView(searchBox(), LinearLayout.LayoutParams(-1, -2))
            val hs = HorizontalScrollView(act)
            hs.isHorizontalScrollBarEnabled = false
            hs.addView(nav, FrameLayout.LayoutParams(-2, -2))
            root.addView(hs, LinearLayout.LayoutParams(-1, -2))
        }

        val right = LinearLayout(act)
        right.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(act)
        scroll = sv
        val frame = CappedFrame(act, dp(760))
        sv.addView(frame, FrameLayout.LayoutParams(-1, -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        val side = if (wide) 24 else 16
        col.pad(side, 4, side, 40)
        frame.addView(col, FrameLayout.LayoutParams(-1, -2))
        body = col
        right.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(
            right,
            if (wide) LinearLayout.LayoutParams(0, -1, 1f) else LinearLayout.LayoutParams(-1, 0, 1f)
        )
        shownSection = ""
        render()
        return root
    }

    private fun render() {
        drawNav()
        val col = body ?: return
        val sameSection = shownSection == act.settingsSection
        val y = if (sameSection) scroll?.scrollY ?: 0 else 0
        shownSection = act.settingsSection
        col.removeAllViews()
        if (query.isNotBlank()) {
            results(col)
            return
        }
        when (act.settingsSection) {
            "themes" -> themes(col)
            "news" -> news(col)
            "privacy" -> privacy(col)
            "memory" -> memory(col)
            "passwords" -> passwords(col)
            "downloads" -> downloadsSection(col)
            "data" -> data(col)
            "about" -> about(col)
            else -> general(col)
        }
        val sv = scroll
        if (sv != null) sv.post { sv.scrollTo(0, y) }
    }

    private fun searchBox(): View {
        val wrap = FrameLayout(act)
        wrap.pad(if (wide) 12 else 16, 10, if (wide) 12 else 16, 6)
        val box = LinearLayout(act)
        box.gravity = Gravity.CENTER_VERTICAL
        box.background = solid(act, C.SOFT, 26f)
        box.pad(16, 0, 8, 0)
        box.addView(icon(act, R.drawable.ic_search, 20), LinearLayout.LayoutParams(dp(20), dp(20)).apply { rightMargin = dp(12) })
        val input = EditText(act)
        input.hint = "Search settings"
        input.setHintTextColor(C.MUTED)
        input.setTextColor(C.INK)
        input.textSize = 16f
        input.background = null
        input.setSingleLine(true)
        input.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
        input.setText(query)
        box.addView(input, LinearLayout.LayoutParams(0, dp(48), 1f))
        val clear = iconButton(act, R.drawable.ic_close, 40, 40, 18, "Clear")
        clear.visibility = if (query.isEmpty()) View.GONE else View.VISIBLE
        clear.setOnClickListener { input.setText("") }
        box.addView(clear, LinearLayout.LayoutParams(dp(40), dp(40)))
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(e: Editable?) {
                query = e?.toString() ?: ""
                clear.visibility = if (query.isEmpty()) View.GONE else View.VISIBLE
                render()
            }
        })
        wrap.addView(box, FrameLayout.LayoutParams(-1, dp(48)))
        return wrap
    }

    /** The list shown instead of a section while something is typed in the search box. */
    private fun results(col: LinearLayout) {
        val words = query.lowercase(Locale.US).split(" ").filter { it.isNotBlank() }
        val hits = index.filter { e ->
            val hay = (e.title + " " + e.about).lowercase(Locale.US)
            words.all { hay.contains(it) }
        }.sortedBy { e -> if (e.title.lowercase(Locale.US).contains(words.firstOrNull() ?: "")) 0 else 1 }
        if (hits.isEmpty()) {
            note(col, "No setting matches \"" + query.trim() + "\".")
            return
        }
        heading(col, if (hits.size == 1) "1 result" else "${hits.size} results")
        card(col).apply {
            for (e in hits) {
                val label = sections.firstOrNull { it.key == e.section }?.label ?: ""
                row(e.title, label, text(act, "›", 22f, C.MUTED)) {
                    act.settingsSection = e.section
                    query = ""
                    hideKeyboard()
                    build2()
                }
            }
        }
    }

    private fun hideKeyboard() {
        try {
            val imm = act.getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            imm.hideSoftInputFromWindow(act.window.decorView.windowToken, 0)
        } catch (e: Exception) {
            // Nothing to hide.
        }
    }

    /** Rebuilds the whole page (used to clear the search box and show the chosen section). */
    private fun build2() {
        act.openSettings(act.settingsSection)
    }

    private fun drawNav() {
        val nav = navHost ?: return
        nav.removeAllViews()
        for (s in sections) {
            val on = act.settingsSection == s.key || (s.key == "general" && sections.none { it.key == act.settingsSection })
            val item = LinearLayout(act)
            item.gravity = Gravity.CENTER_VERTICAL
            if (wide) {
                item.pad(16, 0, 16, 0)
                item.background = if (on) solid(act, C.MINT, 26f) else withRipple(null, solid(act, Color.WHITE, 26f))
                item.addView(icon(act, s.icon, 22), LinearLayout.LayoutParams(dp(22), dp(22)).apply { rightMargin = dp(16) })
                item.addView(text(act, s.label, 15.5f, C.INK, on))
                nav.addView(item, lp(-1, dp(50)).apply { bottomMargin = dp(4) })
            } else {
                item.pad(14, 0, 16, 0)
                item.background = if (on) solid(act, C.MINT, 20f) else solid(act, C.SOFT, 20f)
                item.addView(icon(act, s.icon, 18), LinearLayout.LayoutParams(dp(18), dp(18)).apply { rightMargin = dp(8) })
                item.addView(text(act, s.label, 14f, C.INK, on))
                nav.addView(item, LinearLayout.LayoutParams(-2, dp(40)).apply { rightMargin = dp(8) })
            }
            item.setOnClickListener {
                if (act.settingsSection != s.key) {
                    act.settingsSection = s.key
                    render()
                }
            }
        }
    }

    // ---- building blocks -------------------------------------------------------------------

    private fun heading(col: LinearLayout, s: String) {
        val h = text(act, s, 14f, C.MUTED, true)
        h.pad(6, 22, 6, 8)
        col.addView(h, lp(-1, -2))
    }

    private fun note(col: LinearLayout, s: String) {
        val t = text(act, s, 13f, C.MUTED)
        t.pad(6, 10, 6, 0)
        col.addView(t, lp(-1, -2))
    }

    private fun card(col: LinearLayout): Card {
        val v = LinearLayout(act)
        v.orientation = LinearLayout.VERTICAL
        v.background = solid(act, C.SOFT, 20f)
        v.clipToOutline = true
        v.outlineProvider = ViewOutlineProvider.BACKGROUND
        col.addView(v, lp(-1, -2))
        return Card(v)
    }

    /** A rounded box of rows with thin lines between them. */
    private inner class Card(val view: LinearLayout) {
        private var count = 0

        fun clear() {
            view.removeAllViews()
            count = 0
        }

        fun add(v: View) {
            if (count++ > 0) {
                val d = View(act)
                d.setBackgroundColor(C.LINE)
                view.addView(d, lp(-1, maxOf(1, dp(1))).apply { leftMargin = dp(16) })
            }
            view.addView(v, lp(-1, -2))
        }

        fun row(
            title: String,
            sub: String? = null,
            trailing: View? = null,
            danger: Boolean = false,
            onClick: (() -> Unit)? = null
        ): View {
            val r = LinearLayout(act)
            r.gravity = Gravity.CENTER_VERTICAL
            r.pad(16, 12, 12, 12)
            r.minimumHeight = dp(58)
            if (onClick != null) {
                r.background = withRipple(null)
                r.setOnClickListener { onClick() }
            }
            val col = LinearLayout(act)
            col.orientation = LinearLayout.VERTICAL
            col.addView(text(act, title, 15.5f, if (danger) 0xFFD93025.toInt() else C.INK, false))
            if (!sub.isNullOrEmpty()) {
                col.addView(text(act, sub, 13f, C.MUTED), lp(-2, -2).apply { topMargin = dp(3) })
            }
            r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            if (trailing != null) r.addView(trailing)
            add(r)
            return r
        }

        fun toggle(title: String, sub: String?, value: Boolean, onChange: (Boolean) -> Unit) {
            val sw = Switch(act)
            sw.isChecked = value
            sw.setOnCheckedChangeListener { _, v -> onChange(v) }
            row(title, sub, sw) { sw.toggle() }
        }

        fun radio(title: String, sub: String?, selected: Boolean, onClick: () -> Unit) {
            row(title, sub, radioMark(selected)) { onClick() }
        }

        fun choice(title: String, names: Array<String>, selected: Int, onPick: (Int) -> Unit) {
            var anchor: View? = null
            val r = row(title, names[selected.coerceIn(0, names.size - 1)], text(act, "›", 22f, C.MUTED)) {
                anchor?.let { showChoice(it, names, selected, onPick) }
            }
            anchor = r
        }
    }

    private fun radioMark(on: Boolean): View {
        val ring = FrameLayout(act)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.TRANSPARENT)
        bg.setStroke(dp(2), if (on) C.INK else C.MUTED)
        ring.background = bg
        if (on) {
            val dot = View(act)
            val d = GradientDrawable()
            d.shape = GradientDrawable.OVAL
            d.setColor(C.INK)
            dot.background = d
            ring.addView(dot, FrameLayout.LayoutParams(dp(10), dp(10), Gravity.CENTER))
        }
        ring.layoutParams = LinearLayout.LayoutParams(dp(22), dp(22))
        return ring
    }

    /** A small pop-up list, same look as the main menu. */
    private fun showChoice(anchor: View, names: Array<String>, selected: Int, onPick: (Int) -> Unit) {
        val panel = LinearLayout(act)
        panel.orientation = LinearLayout.VERTICAL
        panel.background = solid(act, C.WHITE, 18f)
        panel.pad(6, 6, 6, 6)
        val holder = arrayOfNulls<PopupWindow>(1)
        for (i in names.indices) {
            val row = LinearLayout(act)
            row.gravity = Gravity.CENTER_VERTICAL
            row.pad(14, 0, 14, 0)
            row.background = withRipple(null)
            row.addView(text(act, names[i], 15f, C.INK, selected == i), LinearLayout.LayoutParams(0, -2, 1f))
            if (selected == i) row.addView(text(act, "✓", 17f, C.INK, true))
            row.setOnClickListener {
                holder[0]?.dismiss()
                if (selected != i) onPick(i)
            }
            panel.addView(row, lp(-1, dp(46)))
        }
        val popup = PopupWindow(panel, dp(230), ViewGroup.LayoutParams.WRAP_CONTENT, true)
        popup.elevation = act.dpf(14f)
        popup.setBackgroundDrawable(null)
        popup.isOutsideTouchable = true
        holder[0] = popup
        popup.showAsDropDown(anchor, maxOf(0, anchor.width - dp(246)), -dp(16))
    }

    // ---- General ---------------------------------------------------------------------------

    /** The News section: what the start page shows under the search bar. */
    private fun news(col: LinearLayout) {
        heading(col, "Start page")
        card(col).apply {
            toggle(
                "News on the start page",
                "Headlines under the search bar, loaded straight from each channel's own feed. Off in private tabs.",
                prefs.newsOn
            ) {
                prefs.newsOn = it
                render()
            }
            if (prefs.newsOn) {
                for (s in NewsSources.all) {
                    toggle(s.name, null, prefs.newsSources.contains(s.id)) { on ->
                        val set = prefs.newsSources.toMutableSet()
                        if (on) set.add(s.id) else set.remove(s.id)
                        prefs.newsSources = set
                    }
                }
            }
        }
        note(col, "News comes straight from each channel's own public feed. Nothing is loaded in private tabs.")
    }

    private fun askCustomEngine() {
        val input = EditText(act)
        input.setText(prefs.customEngine.ifEmpty { "https://example.com/search?q=%s" })
        input.setSingleLine(true)
        input.setSelectAllOnFocus(true)
        val box = FrameLayout(act)
        box.setPadding(act.dp(20), act.dp(8), act.dp(20), 0)
        box.addView(input, FrameLayout.LayoutParams(-1, -2))
        AlertDialog.Builder(act)
            .setTitle("Custom search engine")
            .setMessage("Paste the address of a search results page and put %s where the search words go.")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                val v = input.text.toString().trim()
                if (v.startsWith("http", true) && v.contains("%s")) {
                    prefs.customEngine = v
                    prefs.searchEngine = Engines.CUSTOM
                    act.toast("Search engine saved")
                } else {
                    act.toast("The address must start with https and contain %s")
                }
                render()
            }
            .setNegativeButton("Cancel") { _, _ -> render() }
            .show()
    }

    private fun general(col: LinearLayout) {
        val engines = Engines.names
        heading(col, "Search")
        card(col).apply {
            choice("Search engine", engines, prefs.searchEngine) { i ->
                if (i == Engines.CUSTOM) {
                    askCustomEngine()
                } else {
                    prefs.searchEngine = i
                    act.toast("Search engine: " + engines[i])
                    render()
                }
            }
            if (prefs.searchEngine == Engines.CUSTOM) {
                row("Custom search address", prefs.customEngine.ifEmpty { "Not set" }, text(act, "›", 22f, C.MUTED)) { askCustomEngine() }
            }
            toggle("Search suggestions", "Shows suggestions from your search engine while you type in the address bar. What you type is sent to it. When off, the address bar only offers search, Perplexity and Wikipedia.", prefs.suggestions) {
                prefs.suggestions = it
                act.toast(if (it) "Suggestions on" else "Suggestions off")
            }
            toggle("SafeSearch", "Applies to Google searches. Other search engines use their own setting.", prefs.safeSearch) {
                prefs.safeSearch = it
                act.toast(if (it) "SafeSearch on" else "SafeSearch off")
            }
        }
        heading(col, "Start page overview")
        card(col).apply {
            radio("Wikipedia overview", "Shows a short summary and pictures from Wikipedia under your search.", prefs.overview == 0) {
                prefs.overview = 0
                act.toast("Start page: Wikipedia overview")
                render()
            }
            radio("AI overview", "Adds an Ask Perplexity button. It opens perplexity.ai in a tab, using your own account and limits.", prefs.overview == 1) {
                prefs.overview = 1
                act.toast("Start page: AI overview")
                render()
            }
            radio("Off", "Just the search bar.", prefs.overview == 2) {
                prefs.overview = 2
                act.toast("Start page overview off")
                render()
            }
        }
        heading(col, "On startup and pages")
        card(col).apply {
            toggle("Restore tabs", "Open the pages you had open last time. Private tabs are never saved.", prefs.restoreTabs) {
                prefs.restoreTabs = it
                if (!it) prefs.session = ""
                act.toast(if (it) "Tabs will be restored" else "Tabs will not be restored")
            }
            toggle("Request desktop site", "Open new tabs the way a computer would see them.", prefs.desktop) {
                prefs.desktop = it
                act.toast(if (it) "New tabs open as desktop sites" else "New tabs open as mobile sites")
            }
        }
        heading(col, "Media and battery")
        card(col).apply {
            toggle("Background play", "Keep sound playing when the screen is off.", prefs.bgPlay) {
                prefs.bgPlay = it
                SiteBridge.bgPlay = it
                act.toast(if (it) "Background play on" else "Background play off")
            }
            toggle(
                "Compatibility video decoding",
                "Turn on if YouTube video looks black, blurry or zoomed in. Uses the engine's own decoder: slower and uses more battery. Restart Air after changing.",
                prefs.softVideo
            ) {
                prefs.softVideo = it
                act.toast("Restart Air to apply")
            }
            row("Battery settings", "Let Android keep Air running in the background", text(act, "›", 22f, C.MUTED)) {
                act.openBatterySettings()
            }
        }
    }

    // ---- Memory ----------------------------------------------------------------------------

    private fun fmtMb(mb: Int): String =
        if (mb >= 1024) String.format(Locale.US, "%.1f GB", mb / 1024f) else "$mb MB"

    private fun memory(col: LinearLayout) {
        val total = MemoryManager.deviceTotalMb(act)
        val max = MemoryManager.maxLimitMb(act)
        val min = MemoryManager.MIN_MB
        val step = MemoryManager.STEP_MB

        heading(col, "Memory limit")
        val c = card(col)
        c.toggle(
            "Limit memory use",
            "When Air uses more than this, the tabs you haven't used for longest go to sleep",
            prefs.ramLimitOn
        ) { v ->
            prefs.ramLimitOn = v
            MemoryManager.enforce()
            render()
        }
        if (prefs.ramLimitOn) {
            val limit = MemoryManager.limitMb(act, prefs)
            val box = LinearLayout(act)
            box.orientation = LinearLayout.VERTICAL
            box.pad(16, 12, 16, 12)
            val label = text(act, fmtMb(limit), 22f, C.INK, true)
            box.addView(label)
            val bar = android.widget.SeekBar(act)
            bar.max = (max - min) / step
            bar.progress = (limit - min) / step
            bar.progressTintList = android.content.res.ColorStateList.valueOf(C.LINK)
            bar.thumbTintList = android.content.res.ColorStateList.valueOf(C.LINK)
            bar.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: android.widget.SeekBar?, p: Int, fromUser: Boolean) {
                    label.text = fmtMb(min + p * step)
                }

                override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}

                override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {
                    prefs.ramLimitMb = min + (sb?.progress ?: 0) * step
                    MemoryManager.enforce()
                }
            })
            box.addView(bar, lp(-1, -2).apply { topMargin = dp(8) })
            val ends = LinearLayout(act)
            ends.addView(text(act, fmtMb(min), 12.5f, C.MUTED), LinearLayout.LayoutParams(0, -2, 1f))
            ends.addView(text(act, fmtMb(max), 12.5f, C.MUTED))
            box.addView(ends, lp(-1, -2))
            c.add(box)
        }
        note(
            col,
            "This device has ${fmtMb(total)} of memory. The limit can go up to ${fmtMb(max)}, so Android and your other apps always have room."
        )

        heading(col, "Right now")
        val now = card(col)
        now.row("Air is using", fmtMb(MemoryManager.usedMb(act)) + "  ·  " + act.browser.liveTabs() + " tabs awake")
        now.row("Free memory now", "Put background tabs to sleep and empty the page caches", text(act, "›", 22f, C.MUTED)) {
            MemoryManager.freeNow()
            act.toast("Freeing memory")
            act.window.decorView.postDelayed({ if (act.settingsSection == "memory") render() }, 1500)
        }
        note(
            col,
            "A sleeping tab stays in the tab bar and reloads when you open it. The tab you are on and any tab playing sound are never put to sleep, " +
                "so one very heavy page can still go over the limit."
        )
    }

    // ---- Themes ----------------------------------------------------------------------------

    private fun themes(col: LinearLayout) {
        run {
            heading(col, "Toolbar")
            card(col).apply {
                toggle("Bookmarks bar", "Show your bookmarks under the address bar", prefs.bookmarkBar) {
                    prefs.bookmarkBar = it
                    act.refreshBookmarkBar()
                }
            }
            heading(col, "Start page background")
            card(col).apply {
                val picture = prefs.bgPicture
                for (i in ThemeBg.names.indices) {
                    radio(ThemeBg.names[i], null, !picture && prefs.bgPreset == i) {
                        prefs.bgPicture = false
                        prefs.bgPreset = i
                        act.reTheme()
                    }
                }
                row("Use my own picture", if (picture) "In use. Tap to choose another." else "Pick any photo from your phone", text(act, "›", 22f, C.MUTED)) {
                    act.pickDocument { uri ->
                        Thread {
                            val ok = ThemeBg.savePicture(act, uri)
                            act.runOnUiThread {
                                if (ok) {
                                    prefs.bgPicture = true
                                    act.reTheme()
                                } else {
                                    act.toast("Couldn't use that picture.")
                                }
                            }
                        }.start()
                    }
                }
                if (picture) {
                    val fits = arrayOf("Fit (show the whole picture)", "Fill (cover, may crop)", "Stretch", "Center (original size)")
                    choice("Picture fit", fits, prefs.bgFit) { i ->
                        prefs.bgFit = i
                        act.reTheme()
                        render()
                    }
                    val dims = arrayOf("No dimming", "Slightly darker", "Darker", "Much darker")
                    val dimVals = intArrayOf(0, 15, 30, 50)
                    var di = 0
                    for (k in dimVals.indices) if (prefs.bgDim >= dimVals[k]) di = k
                    choice("Darken picture", dims, di) { i ->
                        prefs.bgDim = dimVals[i]
                        act.reTheme()
                        render()
                    }
                    row("Remove my picture", null, null) {
                        ThemeBg.removePicture(act)
                        prefs.bgPicture = false
                        act.reTheme()
                    }
                }
            }
            note(col, "This colour or picture shows behind the start page and the tab view.")
        }
        heading(col, "Theme")
        val box = LinearLayout(act)
        box.background = solid(act, C.SOFT, 20f)
        box.pad(10, 14, 10, 12)
        val names = arrayOf("System default", "Light", "Dark")
        for (i in names.indices) {
            box.addView(themeTile(i, names[i]), LinearLayout.LayoutParams(0, -2, 1f).apply {
                leftMargin = dp(6); rightMargin = dp(6)
            })
        }
        col.addView(box, lp(-1, -2))
        note(col, "System default follows your phone's light or dark setting. Web pages follow the theme too.")

        heading(col, "Page zoom")
        card(col).apply {
            val value = text(act, prefs.zoom.toString() + "%", 15f, C.INK, true)
            value.gravity = Gravity.CENTER
            fun step(label: String, by: Int): TextView {
                val b = text(act, label, 20f, C.INK, true)
                b.gravity = Gravity.CENTER
                b.background = solid(act, C.WHITE, 20f)
                b.setOnClickListener {
                    prefs.zoom = prefs.zoom + by
                    Engine.apply(prefs)
                    value.text = prefs.zoom.toString() + "%"
                }
                return b
            }
            val controls = LinearLayout(act)
            controls.gravity = Gravity.CENTER_VERTICAL
            controls.addView(step("−", -10), LinearLayout.LayoutParams(dp(40), dp(40)))
            controls.addView(value, LinearLayout.LayoutParams(dp(60), -2))
            controls.addView(step("+", 10), LinearLayout.LayoutParams(dp(40), dp(40)))
            row("Text and page size", "Makes pages larger or smaller", controls)
        }
    }

    /** A little picture of a window in the theme, with a blue ring around the chosen one. */
    private fun themeTile(index: Int, name: String): View {
        val on = prefs.theme == index
        val tile = LinearLayout(act)
        tile.orientation = LinearLayout.VERTICAL
        tile.gravity = Gravity.CENTER_HORIZONTAL

        val ringBox = FrameLayout(act)
        ringBox.background = if (on) skyRing(act, 18f) else null
        ringBox.pad(3, 3, 3, 3)
        val preview = FrameLayout(act)
        preview.background = solid(act, C.WHITE, 15f)
        preview.clipToOutline = true
        preview.outlineProvider = ViewOutlineProvider.BACKGROUND
        when (index) {
            1 -> preview.addView(miniWindow(0xFFF4F2E9.toInt(), 0xFFFFFFFF.toInt()), FrameLayout.LayoutParams(-1, -1))
            2 -> preview.addView(miniWindow(0xFF101412.toInt(), 0xFF343B38.toInt()), FrameLayout.LayoutParams(-1, -1))
            else -> {
                val halves = LinearLayout(act)
                halves.addView(miniWindow(0xFFF4F2E9.toInt(), 0xFFFFFFFF.toInt()), LinearLayout.LayoutParams(0, -1, 1f))
                halves.addView(miniWindow(0xFF101412.toInt(), 0xFF343B38.toInt()), LinearLayout.LayoutParams(0, -1, 1f))
                preview.addView(halves, FrameLayout.LayoutParams(-1, -1))
            }
        }
        ringBox.addView(preview, FrameLayout.LayoutParams(-1, -1))
        tile.addView(ringBox, lp(-1, dp(84)))

        val label = LinearLayout(act)
        label.gravity = Gravity.CENTER_VERTICAL
        label.addView(radioMark(on), LinearLayout.LayoutParams(dp(20), dp(20)).apply { rightMargin = dp(8) })
        label.addView(text(act, name, 14f, C.INK, on))
        tile.addView(label, lp(-2, -2).apply { topMargin = dp(10) })

        tile.setOnClickListener {
            if (prefs.theme != index) {
                prefs.theme = index
                act.toast("Theme: $name")
                act.reTheme()
            }
        }
        return tile
    }

    private fun miniWindow(bg: Int, bar: Int): View {
        val f = FrameLayout(act)
        f.setBackgroundColor(bg)
        val b = View(act)
        b.background = solid(act, bar, 6f)
        f.addView(b, FrameLayout.LayoutParams(-1, dp(14)).apply {
            topMargin = dp(10); leftMargin = dp(8); rightMargin = dp(8)
        })
        val line = View(act)
        line.background = solid(act, bar, 3f)
        f.addView(line, FrameLayout.LayoutParams(-1, dp(6)).apply {
            topMargin = dp(36); leftMargin = dp(8); rightMargin = dp(22)
        })
        return f
    }

    // ---- Privacy and security --------------------------------------------------------------

    private fun privacy(col: LinearLayout) {
        heading(col, "Cookies and site data")
        card(col).apply {
            val modes = listOf(
                Triple(0, "Allow all cookies", "Sites can remember you everywhere. Least private."),
                Triple(1, "Block cross-site tracking cookies (recommended)", "Stops cookies that follow you from site to site."),
                Triple(2, "Block all third-party cookies", "Cookies only work on the site you are on. Some sign-in buttons may stop working."),
                Triple(3, "Block all cookies", "Sites can't remember you at all. Most sites will not let you sign in.")
            )
            for ((mode, title, sub) in modes) {
                radio(title, sub, prefs.cookieMode == mode) {
                    prefs.cookieMode = mode
                    Engine.apply(prefs)
                    act.toast("Cookie setting saved")
                    render()
                }
            }
            toggle("Clear cookies and site data on exit", "Forgets them the next time Air starts.", prefs.clearOnExit) {
                prefs.clearOnExit = it
            }
            row("Clear browsing data", "History, cookies and cached files", text(act, "›", 22f, C.MUTED)) {
                showClearDialog()
            }
        }

        heading(col, "Air Block")
        card(col).apply {
            val n = String.format(Locale.US, "%,d", Urls.adHostCount())
            toggle(
                "Air Block",
                "Stops requests to $n known ad and tracker servers before they load, and hides the empty ad boxes. " +
                    "It never changes a page's own layout.",
                prefs.adBlock
            ) {
                if (!prefs.adBlockExt) {
                    act.toast("Air Block is turned off in Extensions. Switch it on there first.")
                } else {
                    prefs.adBlock = it
                    Engine.apply(prefs)
                    act.toast(if (it) "Air Block on" else "Air Block off")
                }
                render()
            }
        }
        if (prefs.adBlock) {
            heading(col, "Blocking strength")
            card(col).apply {
                val levels = arrayOf(
                    "Light" to "Only servers that exist just to show ads. The safest choice for fussy sites.",
                    "Standard" to "Also trackers loaded by other sites, and hides empty ad boxes. Recommended.",
                    "Strong" to "Also blocks requests that look like ads and hides common ad boxes.",
                    "Aggressive" to "The strictest: wide matching, removes \"turn off your ad blocker\" walls and blocks fingerprinting. A few sites may not like it."
                )
                for (i in levels.indices) {
                    radio(levels[i].first, levels[i].second, prefs.adLevel == i) {
                        prefs.adLevel = i
                        SiteBridge.adLevel = i
                        Engine.apply(prefs)
                        act.toast("Blocking strength: " + levels[i].first)
                        render()
                    }
                }
            }
            note(
                col,
                "YouTube, sign-in pages, banks, shops, streaming and captcha pages are always kept on the gentlest setting so they keep working. " +
                    "Changes apply the next time a page loads."
            )
        }

        heading(col, "Air Sentinel")
        card(col).apply {
            toggle(
                "Air Sentinel",
                "Scans your downloads, warns about fake look-alike addresses, risky files and dangerous sites. " +
                    "It protects what you do in Air; it does not scan the rest of your device.",
                prefs.antivirus
            ) {
                if (!prefs.sentinelExt) {
                    act.toast("Air Sentinel is turned off in Extensions. Switch it on there first.")
                } else {
                    prefs.antivirus = it
                }
                Engine.apply(prefs)
                render()
            }
        }

        heading(col, "Safe browsing and hacker protection")
        card(col).apply {
            toggle("Warn about dangerous sites", "Blocks phishing and malware pages before they open.", prefs.safeBrowsing) {
                prefs.safeBrowsing = it
                Engine.apply(prefs)
            }
            toggle("HTTPS-only mode", "Only opens sites over a secure connection. Sites without one will not load.", prefs.httpsOnly) {
                prefs.httpsOnly = it
                Engine.apply(prefs)
            }
            toggle("Block pop-ups and sneaky redirects", "Stops pages from opening windows you didn't ask for.", prefs.blockPopups) {
                prefs.blockPopups = it
            }
            toggle("Website notifications", "Lets sites ask to send you notifications. Each site still has to ask, and you can block it.", prefs.siteNotifications) {
                prefs.siteNotifications = it
            }
            toggle("Stop pages opening other apps", "A page can only open another app after you tap something.", prefs.blockExternal) {
                prefs.blockExternal = it
            }
            toggle("Remove tracking from links", "Strips utm_, fbclid, gclid and similar tags from addresses.", prefs.stripTracking) {
                prefs.stripTracking = it
            }
            toggle("Fingerprinting protection", "Makes it harder for sites to identify your device. Can affect video and canvas sites, so it is off by default (Aggressive turns it on).", prefs.fingerprint) {
                prefs.fingerprint = it
                Engine.apply(prefs)
            }
            toggle("Warn before risky downloads", "Asks first about programs, scripts and files from insecure links.", prefs.warnDownloads) {
                prefs.warnDownloads = it
            }
            toggle("Send Global Privacy Control", "Tells sites not to sell or share your data.", prefs.gpc) {
                prefs.gpc = it
                Engine.apply(prefs)
            }
        }

        heading(col, "Site permissions")
        card(col).apply {
            toggle("Ask before using location", "Turn off to block every site from your location.", prefs.askLocation) {
                prefs.askLocation = it
            }
            toggle("Ask before using camera and microphone", "Turn off to block every site from both.", prefs.askMedia) {
                prefs.askMedia = it
            }
        }

        heading(col, "Private tabs")
        card(col).apply {
            toggle("Hide private tabs", "Keeps private tabs out of screenshots and the recent-apps view.", prefs.secureTabs) {
                prefs.secureTabs = it
                act.browser.active()?.let { t -> act.applyPrivacy(t) }
                act.toast(if (it) "Private tabs are hidden" else "Private tabs can be captured")
            }
        }
    }

    private fun showClearDialog() {
        var range = "all"
        var hist = true
        var cookies = true
        var cache = true
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.pad(20, 8, 20, 0)

        val chips = LinearLayout(act)
        fun drawChips() {
            chips.removeAllViews()
            for ((key, label) in listOf("hour" to "Last hour", "day" to "Today", "all" to "All time")) {
                val on = range == key
                val c = text(act, label, 13f, if (on) C.ON_INK else C.INK, true)
                c.gravity = Gravity.CENTER
                c.background = solid(act, if (on) C.INK else C.SOFT, 18f)
                c.setOnClickListener {
                    range = key
                    drawChips()
                }
                chips.addView(c, LinearLayout.LayoutParams(0, dp(36), 1f).apply { rightMargin = dp(8) })
            }
        }
        drawChips()
        box.addView(chips, lp(-1, -2).apply { bottomMargin = dp(6) })

        fun check(label: String, value: Boolean, set: (Boolean) -> Unit) {
            val cb = CheckBox(act)
            cb.text = label
            cb.isChecked = value
            cb.setOnCheckedChangeListener { _, v -> set(v) }
            box.addView(cb, lp(-1, dp(44)))
        }
        check("Browsing history", hist) { hist = it }
        check("Cookies and site data", cookies) { cookies = it }
        check("Cached images and files", cache) { cache = it }

        AlertDialog.Builder(act)
            .setTitle("Clear browsing data")
            .setView(box)
            .setPositiveButton("Delete data") { _, _ ->
                if (!hist && !cookies && !cache) {
                    act.toast("Choose what to delete.")
                } else {
                    if (hist) {
                        val now = System.currentTimeMillis()
                        val since = when (range) {
                            "hour" -> now - 3600000L
                            "day" -> now - (now % 86400000L)
                            else -> 0L
                        }
                        act.browser.clearHistory(since)
                    }
                    Engine.clearData(cookies, cache)
                    act.toast("Browsing data deleted.")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---- Passwords -------------------------------------------------------------------------

    private fun passwords(col: LinearLayout) {
        val vault = act.vault
        heading(col, "Passwords")
        card(col).apply {
            toggle("Offer to save passwords", "Passwords are encrypted on this device with a key that never leaves it.", prefs.savePasswords) {
                prefs.savePasswords = it
            }
            row("Add password", "Save a sign-in by hand", text(act, "+", 22f, C.MUTED)) { showAddDialog() }
        }

        val total = vault.count()
        heading(col, "Saved passwords ($total)")
        if (total == 0) {
            note(col, "Sign-ins you save will appear here. You can also import them from Chrome or Brave in Import and export.")
        } else {
            val search = EditText(act)
            search.hint = "Search passwords"
            search.setHintTextColor(C.HINT)
            search.setTextColor(C.INK)
            search.textSize = 15f
            search.isSingleLine = true
            search.setText(passwordQuery)
            search.background = solid(act, C.SOFT, 24f)
            search.pad(20, 0, 20, 0)
            col.addView(search, lp(-1, dp(48)).apply { bottomMargin = dp(10) })
            val list = card(col)
            fillPasswords(list)
            search.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    passwordQuery = s?.toString()?.trim()?.lowercase(Locale.getDefault()).orEmpty()
                    fillPasswords(list)
                }

                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }

        heading(col, "More")
        card(col).apply {
            val never = prefs.neverSave
            if (never.isNotEmpty()) {
                row("Sites that never save passwords", "${never.size} site(s). Tap to ask again.") {
                    prefs.neverSave = emptySet()
                    act.toast("Air will ask again")
                    render()
                }
            }
            if (total > 0) {
                row("Delete all passwords", "Removes every saved password from this device", null, true) {
                    AlertDialog.Builder(act)
                        .setTitle("Delete all passwords?")
                        .setMessage("This can't be undone. Export them first if you want a copy.")
                        .setPositiveButton("Delete") { _, _ ->
                            act.requireAuth("Delete all saved passwords") {
                                vault.deleteAll()
                                act.toast("Passwords deleted")
                                render()
                            }
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            }
        }
    }

    private fun fillPasswords(list: Card) {
        list.clear()
        val q = passwordQuery
        val matches = act.vault.all().filter {
            q.isEmpty() || it.host.lowercase(Locale.getDefault()).contains(q) ||
                it.username.lowercase(Locale.getDefault()).contains(q)
        }
        if (matches.isEmpty()) {
            val t = text(act, "No passwords match.", 14f, C.MUTED)
            t.pad(16, 18, 16, 18)
            list.add(t)
            return
        }
        for (l in matches.take(150)) {
            list.row(l.host, if (l.username.isEmpty()) "(no username)" else l.username, text(act, "›", 22f, C.MUTED)) {
                showLoginDialog(l)
            }
        }
        if (matches.size > 150) {
            val t = text(act, "Showing the first 150. Search to find the others.", 13f, C.MUTED)
            t.pad(16, 14, 16, 14)
            list.add(t)
        }
    }

    private fun showLoginDialog(l: Login) {
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.pad(22, 8, 22, 0)

        fun label(s: String) {
            box.addView(text(act, s, 12f, C.MUTED, true), lp(-2, -2).apply { topMargin = dp(14) })
        }

        fun action(s: String, run: () -> Unit): TextView {
            val a = text(act, s, 14f, C.SKY_C, true)
            a.pad(12, 8, 4, 8)
            a.setOnClickListener { run() }
            return a
        }

        label("Website")
        box.addView(TextView(act).apply { text = l.origin; textSize = 16f })

        label("Username")
        val userRow = LinearLayout(act)
        userRow.gravity = Gravity.CENTER_VERTICAL
        userRow.addView(
            TextView(act).apply { text = if (l.username.isEmpty()) "(none)" else l.username; textSize = 16f },
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        if (l.username.isNotEmpty()) userRow.addView(action("Copy") { copyText(l.username) })
        box.addView(userRow)

        label("Password")
        val dots = "••••••••••"
        val pw = TextView(act)
        pw.text = dots
        pw.textSize = 16f
        var shown = false
        val showBtn = action("Show") {}
        showBtn.setOnClickListener {
            if (shown) {
                shown = false
                pw.text = dots
                showBtn.text = "Show"
            } else {
                act.requireAuth("Show this saved password") {
                    shown = true
                    pw.text = l.password
                    showBtn.text = "Hide"
                }
            }
        }
        val pwRow = LinearLayout(act)
        pwRow.gravity = Gravity.CENTER_VERTICAL
        pwRow.addView(pw, LinearLayout.LayoutParams(0, -2, 1f))
        pwRow.addView(showBtn)
        pwRow.addView(action("Copy") { act.requireAuth("Copy this saved password") { copyText(l.password) } })
        box.addView(pwRow)

        AlertDialog.Builder(act)
            .setTitle(l.host)
            .setView(box)
            .setPositiveButton("Done", null)
            .setNeutralButton("Delete") { _, _ ->
                act.vault.delete(l.id)
                act.toast("Password deleted")
                render()
            }
            .show()
    }

    private fun showAddDialog() {
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.pad(22, 8, 22, 0)
        val site = EditText(act)
        site.hint = "Website, like example.com"
        site.isSingleLine = true
        site.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        val user = EditText(act)
        user.hint = "Username or email"
        user.isSingleLine = true
        user.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        val pass = EditText(act)
        pass.hint = "Password"
        pass.isSingleLine = true
        pass.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        box.addView(site, lp(-1, -2))
        box.addView(user, lp(-1, -2))
        box.addView(pass, lp(-1, -2))
        AlertDialog.Builder(act)
            .setTitle("Add password")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                val raw = site.text.toString().trim()
                val address = if (raw.contains("://")) raw else "https://$raw"
                val saved = raw.isNotEmpty() && act.vault.save(address, user.text.toString().trim(), pass.text.toString())
                act.toast(if (saved) "Password saved" else "Enter a website and a password.")
                if (saved) render()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun copyText(value: String) {
        val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("copied", value))
        act.toast("Copied")
    }

    // ---- Downloads -------------------------------------------------------------------------

    private fun downloadsSection(col: LinearLayout) {
        heading(col, "Downloads")
        card(col).apply {
            row("Location", "Downloads folder on this device", text(act, "Downloads", 14f, C.MUTED))
            row("Open downloads", "See, search and open what you have downloaded", text(act, "›", 22f, C.MUTED)) {
                act.openTool("downloads")
            }
            row("Open the Android Downloads app", null, text(act, "›", 22f, C.MUTED)) {
                act.downloads.openSystemDownloads()
            }
            row("Clear download list", "Takes everything off the list. The files stay on your device.") {
                act.downloads.clearList()
                act.toast("Download list cleared")
            }
        }
        heading(col, "Safety")
        card(col).apply {
            row("Download safety checks", "Warnings for programs and insecure links are in Privacy and security", text(act, "›", 22f, C.MUTED)) {
                act.settingsSection = "privacy"
                render()
            }
        }
    }

    // ---- Import and export -----------------------------------------------------------------

    private fun data(col: LinearLayout) {
        heading(col, "Move from another browser")
        card(col).apply {
            row("Import from another browser", "Pick your exported bookmarks, passwords and history files together", text(act, "›", 22f, C.MUTED)) {
                act.pickDocuments { uris -> BrowserImport.run(act, uris) { render() } }
            }
            row("How do I get these files?", "Steps for Chrome, Brave, Edge and Firefox", text(act, "›", 22f, C.MUTED)) {
                AlertDialog.Builder(act)
                    .setTitle("Exporting from your old browser")
                    .setMessage(
                        "Chrome, Brave and Edge (on a computer):\n" +
                            "- Bookmarks: open the bookmark manager, menu, Export bookmarks.\n" +
                            "- Passwords: Settings, Passwords, Export passwords.\n" +
                            "- History: Google Takeout, choose Chrome, then pick the History.json file.\n\n" +
                            "Firefox:\n" +
                            "- Bookmarks: Library, Import and Backup, Export Bookmarks to HTML.\n" +
                            "- Passwords: about:logins, menu, Export Logins.\n\n" +
                            "Send the files to this phone, tap Import, and choose them all at once.\n\n" +
                            "Cookies, open tabs and saved cards can't be moved: browsers lock them to the device they were made on."
                    )
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
        heading(col, "Bookmarks")
        card(col).apply {
            row("Import bookmarks", "From a Chrome, Brave, Edge or Firefox .html file", text(act, "›", 22f, C.MUTED)) {
                act.pickDocument { uri -> importBookmarks(uri) }
            }
            row("Export bookmarks", "${act.browser.bookmarks.size} bookmarks, saved as an .html file", text(act, "›", 22f, C.MUTED)) {
                act.createDocument("air-bookmarks.html", "text/html") { uri ->
                    val ok = writeText(uri, BookmarkIo.toHtml(act.browser.bookmarks.toList()))
                    act.toast(if (ok) "Bookmarks exported" else "Couldn't save the file.")
                }
            }
        }
        heading(col, "Passwords")
        card(col).apply {
            row("Import passwords", "From a .csv file (Chrome, Brave, Edge, Firefox, Bitwarden)", text(act, "›", 22f, C.MUTED)) {
                act.pickDocument { uri -> importPasswords(uri) }
            }
            row("Export passwords", "${act.vault.count()} saved. The file is not encrypted.", text(act, "›", 22f, C.MUTED)) {
                exportPasswords()
            }
        }
        note(col, "These files use the same formats as Chrome and Brave, so you can move your data in or out of Air. Delete a passwords file as soon as you are done with it.")
    }

    private fun importBookmarks(uri: Uri) {
        val text = readText(uri)
        if (text == null) {
            act.toast("Couldn't read that file.")
            return
        }
        val have = act.browser.bookmarks.map { it.url }.toHashSet()
        val fresh = BookmarkIo.parse(text).filter { have.add(it.url) }
        if (fresh.isEmpty()) {
            act.toast("No new bookmarks found in that file.")
            return
        }
        act.browser.bookmarks.addAll(fresh)
        act.browser.saveBookmarks()
        act.toast("Imported ${fresh.size} bookmarks")
        render()
    }

    private fun importPasswords(uri: Uri) {
        val text = readText(uri)
        if (text == null) {
            act.toast("Couldn't read that file.")
            return
        }
        val added = act.vault.importCsv(text)
        act.toast(if (added > 0) "Imported $added passwords" else "No new passwords found in that file.")
        render()
    }

    private fun exportPasswords() {
        if (act.vault.count() == 0) {
            act.toast("There are no saved passwords to export.")
            return
        }
        AlertDialog.Builder(act)
            .setTitle("Export passwords?")
            .setMessage(
                "The file will hold your passwords as plain text. Anyone who can open it can read them. " +
                    "Keep it somewhere safe and delete it when you are done."
            )
            .setPositiveButton("Continue") { _, _ ->
                act.requireAuth("Export your saved passwords") {
                    act.createDocument("air-passwords.csv", "text/csv") { uri ->
                        val ok = writeText(uri, act.vault.toCsv())
                        act.toast(if (ok) "Passwords exported" else "Couldn't save the file.")
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun readText(uri: Uri): String? {
        return try {
            act.contentResolver.openInputStream(uri)?.use { s ->
                val bytes = s.readBytes()
                if (bytes.size > 25000000) null else String(bytes, Charsets.UTF_8)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun writeText(uri: Uri, text: String): Boolean {
        return try {
            val out = act.contentResolver.openOutputStream(uri, "wt") ?: return false
            out.use { it.write(text.toByteArray(Charsets.UTF_8)) }
            true
        } catch (e: Exception) {
            false
        }
    }

    // ---- About -----------------------------------------------------------------------------

    private fun about(col: LinearLayout) {
        heading(col, "About")
        card(col).apply {
            row("Air 2.0", "Engine: GeckoView (the Firefox engine)")
            row("Licences", "Air's code: MIT. The Air logo: all rights reserved. Engine: GeckoView, Mozilla Public License 2.0. See LICENSE, LOGO-LICENSE.md and NOTICE.md in the source.")
            row(
                "Ad and tracker lists",
                "Built from EasyList and EasyPrivacy (CC BY-SA 3.0 / GPLv3) plus a short hand-picked list. " +
                    String.format(Locale.US, "%,d", Urls.adHostCount()) + " servers blocked."
            )
        }
    }
}
