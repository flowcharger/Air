package com.liquidair.browser

import android.Manifest
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoSession

/** Site permission questions: location, camera, microphone and the Android side of them. */
class Permissions(private val act: MainActivity) {

    /** Sites that keep asking after being told no, and sites with a look-alike address, are refused quietly by Air Sentinel. */
    private val refused = HashMap<String, Int>()

    private fun guarded(host: String, what: String): Boolean {
        if (!act.prefs.antivirus) return false
        if (Antivirus.suspiciousAddress("https://$host") != null) return true
        return (refused["$host|$what"] ?: 0) >= 2
    }

    private fun askSite(host: String, what: String, icon: Int, answer: (Boolean, Boolean) -> Unit) {
        act.sitePrompt.ask(host, what, icon) { allow, remember ->
            if (!allow && !remember) refused["$host|$what"] = (refused["$host|$what"] ?: 0) + 1
            answer(allow, remember)
        }
    }

    fun android(perms: Array<out String>?, callback: GeckoSession.PermissionDelegate.Callback) {
        val list = perms?.toList().orEmpty()
        act.askAndroid(list) { ok -> if (ok) callback.grant() else callback.reject() }
    }

    fun content(perm: GeckoSession.PermissionDelegate.ContentPermission): GeckoResult<Int>? {
        val result = GeckoResult<Int>()
        val kind = perm.permission
        return when (kind) {
            GeckoSession.PermissionDelegate.PERMISSION_GEOLOCATION -> {
                val host = Urls.hostOf(perm.uri)
                val site = Sites.location(host)
                if (site == Sites.BLOCK || (site == Sites.ASK && !act.prefs.askLocation)) {
                    return GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY)
                }
                if (site == Sites.ALLOW) {
                    return GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW)
                }
                val h = Urls.hostOf(perm.uri)
                if (guarded(h, "Use your location")) {
                    return GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY)
                }
                askSite(h, "Use your location", R.drawable.ic_pin) { allow, remember ->
                    if (remember) Sites.setLocation(h, if (allow) Sites.ALLOW else Sites.BLOCK)
                    result.complete(
                        if (allow) GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW
                        else GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY
                    )
                }
                result
            }
            GeckoSession.PermissionDelegate.PERMISSION_DESKTOP_NOTIFICATION -> {
                val h = Urls.hostOf(perm.uri)
                val site = Sites.notify(h)
                val deny = GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY
                val allow = GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW
                if (!act.prefs.siteNotifications || site == Sites.BLOCK || guarded(h, "Show notifications")) {
                    return GeckoResult.fromValue(deny)
                }
                val grant = {
                    // Android 13 and newer also want the phone-level permission.
                    act.askAndroid(listOf("android.permission.POST_NOTIFICATIONS")) { ok -> result.complete(if (ok) allow else deny) }
                }
                if (site == Sites.ALLOW) {
                    grant()
                } else {
                    askSite(h, "Show notifications", R.drawable.ic_bell) { yes, remember ->
                        if (remember) Sites.setNotify(h, if (yes) Sites.ALLOW else Sites.BLOCK)
                        if (yes) grant() else result.complete(deny)
                    }
                }
                result
            }
            GeckoSession.PermissionDelegate.PERMISSION_AUTOPLAY_AUDIBLE ->
                GeckoResult.fromValue(
                    if (Sites.autoplay(Urls.hostOf(perm.uri)) == Sites.BLOCK) GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY
                    else GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW
                )
            GeckoSession.PermissionDelegate.PERMISSION_STORAGE_ACCESS ->
                GeckoResult.fromValue(
                    if (Sites.crossSite(Urls.hostOf(perm.uri)) == Sites.BLOCK) GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY
                    else GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW
                )
            GeckoSession.PermissionDelegate.PERMISSION_MEDIA_KEY_SYSTEM_ACCESS -> {
                val h = Urls.hostOf(perm.uri)
                val site = Sites.drm(h)
                if (site == Sites.BLOCK) {
                    return GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY)
                }
                if (site == Sites.ALLOW) {
                    return GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW)
                }
                askSite(h, "Play protected content", R.drawable.ic_lock) { allow, remember ->
                    if (remember) Sites.setDrm(h, if (allow) Sites.ALLOW else Sites.BLOCK)
                    result.complete(
                        if (allow) GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW
                        else GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY
                    )
                }
                result
            }
            GeckoSession.PermissionDelegate.PERMISSION_AUTOPLAY_INAUDIBLE,
            GeckoSession.PermissionDelegate.PERMISSION_PERSISTENT_STORAGE ->
                GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW)
            else ->
                GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY)
        }
    }

    fun media(
        uri: String,
        video: Array<out GeckoSession.PermissionDelegate.MediaSource>?,
        audio: Array<out GeckoSession.PermissionDelegate.MediaSource>?,
        callback: GeckoSession.PermissionDelegate.MediaCallback
    ) {
        val wantVideo = video != null && video.isNotEmpty()
        val wantAudio = audio != null && audio.isNotEmpty()
        val host = Urls.hostOf(uri)
        if (guarded(host, "Use your camera") || guarded(host, "Use your microphone") || guarded(host, "Use your camera and microphone")) {
            callback.reject()
            return
        }
        val cam = Sites.camera(host)
        val mic = Sites.mic(host)
        if ((wantVideo && cam == Sites.BLOCK) || (wantAudio && mic == Sites.BLOCK)) {
            callback.reject()
            return
        }
        val allowed = (!wantVideo || cam == Sites.ALLOW) && (!wantAudio || mic == Sites.ALLOW)
        if (!allowed && !act.prefs.askMedia) {
            callback.reject()
            return
        }
        val what = when {
            wantVideo && wantAudio -> "camera and microphone"
            wantVideo -> "camera"
            else -> "microphone"
        }
        val decide: ((Boolean) -> Unit) -> Unit = { answer ->
            if (allowed) {
                answer(true)
            } else {
                val icon = if (wantVideo) R.drawable.ic_camera else R.drawable.ic_mic
                askSite(host, "Use your $what", icon) { allow, remember ->
                    if (remember) {
                        val v = if (allow) Sites.ALLOW else Sites.BLOCK
                        if (wantVideo) Sites.setCamera(host, v)
                        if (wantAudio) Sites.setMic(host, v)
                    }
                    answer(allow)
                }
            }
        }
        decide { allow ->
            if (!allow) {
                callback.reject()
                return@decide
            }
            val needed = ArrayList<String>()
            if (wantVideo) needed.add(Manifest.permission.CAMERA)
            if (wantAudio) needed.add(Manifest.permission.RECORD_AUDIO)
            act.askAndroid(needed) { ok ->
                if (!ok) {
                    callback.reject()
                } else {
                    val v: GeckoSession.PermissionDelegate.MediaSource? = video?.firstOrNull()
                    val a: GeckoSession.PermissionDelegate.MediaSource? = audio?.firstOrNull()
                    callback.grant(v, a)
                }
            }
        }
    }
}
