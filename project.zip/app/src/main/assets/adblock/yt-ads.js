// YouTube ads, kept deliberately gentle.
//
// Earlier versions rewrote YouTube's own data and hid the player's video element, which could leave
// the player half black or zoomed. This version never touches the player's data, size or visibility:
//  1. Ad boxes, banners and promoted rows in the page are hidden (plain display:none).
//  2. While YouTube itself marks the player as "showing an ad", the ad is muted, sped up and
//     skipped when a Skip button exists. As soon as the ad ends, sound and speed go back exactly
//     as they were. Outside an ad this script does nothing at all.
// Not used on YouTube Music. Turned off for a site with the Shields switch.
(function () {
  "use strict";
  if (location.hostname === "music.youtube.com") return;

  var enabled = true;
  var level = 1;
  var style = null;
  var saved = null;

  var HIDE = [
    "#masthead-ad", "#player-ads", ".ytp-ad-overlay-container", ".ytp-ad-overlay-slot",
    "ytd-ad-slot-renderer", "ytd-in-feed-ad-layout-renderer", "ytd-display-ad-renderer",
    "ytd-promoted-sparkles-web-renderer", "ytd-promoted-video-renderer", "ytd-banner-promo-renderer",
    "ytd-statement-banner-renderer", "ytd-companion-slot-renderer", "ytd-action-companion-ad-renderer",
    "ytd-player-legacy-desktop-watch-ads-renderer", "ytm-promoted-sparkles-web-renderer",
    "ytm-companion-ad-renderer", "ytm-promoted-video-renderer", "ytm-ad-slot-renderer"
  ].join(",") + "{display:none!important}";

  function syncStyle() {
    if (enabled && !style) {
      style = document.createElement("style");
      style.textContent = HIDE;
      (document.head || document.documentElement).appendChild(style);
    } else if (!enabled && style) {
      style.remove();
      style = null;
    }
  }

  browser.runtime.sendMessage({ t: "cfg" }).then(
    function (c) {
      if (c) {
        enabled = c.ads !== false;
        level = c.level;
      }
      syncStyle();
    },
    function () { syncStyle(); }
  );

  var SKIP = [
    ".ytp-skip-ad-button", ".ytp-ad-skip-button", ".ytp-ad-skip-button-modern",
    ".ytp-ad-skip-button-container button", ".ytp-ad-skip-button-slot button"
  ].join(",");

  function player() {
    return document.querySelector("#movie_player") || document.querySelector(".html5-video-player");
  }

  function restore(v) {
    if (!saved) return;
    try { v.muted = saved.muted; } catch (e) {}
    try { v.playbackRate = saved.rate; } catch (e) {}
    saved = null;
  }

  function tick() {
    if (!enabled || level === 0) return;
    var p = player();
    if (!p) return;
    var v = p.querySelector("video.html5-main-video") || p.querySelector("video");
    if (!v) return;
    // Only when YouTube says an ad is playing AND its ad interface is really on screen.
    var ad = p.classList.contains("ad-showing") &&
      !!p.querySelector(".ytp-ad-player-overlay, .ytp-ad-player-overlay-layout, .ytp-ad-text, .ytp-ad-preview-container, .ytp-ad-simple-ad-badge");
    if (ad) {
      if (!saved) saved = { muted: v.muted, rate: v.playbackRate };
      try { v.muted = true; } catch (e) {}
      var skip = p.querySelector(SKIP);
      if (skip) {
        skip.click();
      } else {
        try { v.playbackRate = 16; } catch (e) {}
        try {
          if (isFinite(v.duration) && v.duration > 0 && v.duration < 180 && v.currentTime < v.duration - 0.3) {
            v.currentTime = v.duration - 0.1;
          }
        } catch (e) {}
      }
    } else {
      restore(v);
      var close = p.querySelector(".ytp-ad-overlay-close-button");
      if (close) close.click();
    }
  }

  setInterval(tick, 300);
})();
