// Stand-in for the Google Publisher Tag: calls succeed and do nothing, so page code never throws.
(function () {
  try {
    var g = window.googletag = window.googletag || {};
    var q = g.cmd = g.cmd || [];
    var self = function () { return slot; };
    var slot = {
      addService: self, setTargeting: self, defineSizeMapping: self, setCollapseEmptyDiv: self,
      getSlotElementId: function () { return ""; }, getAdUnitPath: function () { return ""; },
      set: self, get: function () { return null; }, clearTargeting: self, updateTargetingFromMap: self
    };
    var svc = {
      enableSingleRequest: self, enableLazyLoad: function () {}, collapseEmptyDivs: function () {},
      setTargeting: function () { return svc; }, addEventListener: function () { return svc; },
      removeEventListener: function () { return true; }, set: function () { return svc; },
      enableAsyncRendering: function () {}, disableInitialLoad: function () {}, setPrivacySettings: function () { return svc; },
      setCentering: function () {}, setForceSafeFrame: function () {}, setSafeFrameConfig: function () {}
    };
    g.apiReady = true;
    g.pubadsReady = true;
    g.pubads = function () { return svc; };
    g.companionAds = function () { return svc; };
    g.content = function () { return svc; };
    g.defineSlot = function () { return slot; };
    g.defineOutOfPageSlot = function () { return slot; };
    g.enableServices = function () {};
    g.display = function () {};
    g.destroySlots = function () { return true; };
    g.sizeMapping = function () { return { addSize: function () { return this; }, build: function () { return []; } }; };
    g.setAdIframeTitle = function () {};
    g.cmd.push = function (fn) { try { if (typeof fn === "function") fn(); } catch (e) {} return 0; };
    for (var i = 0; i < q.length; i++) { try { if (typeof q[i] === "function") q[i](); } catch (e) {} }
  } catch (e) {}
})();
