// Stand-in for the ad script: pages that wait for it carry on, and no ad is shown.
(function () {
  try {
    var q = window.adsbygoogle;
    var stub = (q && typeof q.push === "function" && q.loaded) ? q : [];
    stub.loaded = true;
    stub.push = function () { return 0; };
    window.adsbygoogle = stub;
  } catch (e) {}
})();
