// Stand-in for a blocked tracking script: pages that call it keep working.
(function () {
  var f = function () {};
  if (!window.dataLayer) window.dataLayer = [];
  if (!window.ga) { window.ga = f; window.ga.loaded = true; window.ga.getAll = function () { return []; }; }
  if (!window.gtag) window.gtag = f;
})();
