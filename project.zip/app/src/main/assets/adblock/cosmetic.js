// Cosmetic filtering, the way Brave does it: after the network blocker has cancelled an ad's
// requests, this hides the empty slot that would be left behind so the page doesn't show that an
// ad was ever there.
//
// It is built not to break weak websites:
//  - Level 0 (Light), fragile pages and sites with Shields down: does nothing.
//  - Level 1 (Standard): only containers that belong to a known ad network.
//  - Level 2 (Strong): also the common "ad slot" class names, and empty wrappers.
//  - Level 3 (Aggressive): also broad names, floating overlays, and anti-adblock walls.
//  - It never hides the page itself, big content blocks (lots of text, or most of the screen on
//    levels below Aggressive), or anything a site's own menu, header or article lives in.
//  - Generic class names are only hidden after a safety check; the early style rule below holds
//    only selectors that belong to a known ad network.
(function () {
  "use strict";
  if (/captcha|challenge/i.test(location.hostname)) return;
  if (window.top !== window) return;

  var NETWORK = [
    "ins.adsbygoogle", ".adsbygoogle", "[id^='google_ads_iframe']", "[id^='google_ads_']",
    "[id^='div-gpt-ad']", "[id^='gpt-ad-']", "[data-google-query-id]",
    "iframe[src*='doubleclick.net']", "iframe[src*='googlesyndication.com']",
    "iframe[src*='/pagead/']", "iframe[src*='amazon-adsystem.com']", "iframe[src*='adnxs.com']",
    "iframe[src*='taboola.com']", "iframe[src*='outbrain.com']",
    ".taboola", "[id^='taboola-']", ".trc_rbox_container", ".OUTBRAIN", "[id^='outbrain-']",
    "#tads", "#tadsb", "#bottomads", "[data-text-ad]"
  ];
  var COMMON = [
    "[data-ad-slot]", ".ad-slot", ".ad-unit", ".adunit", ".ad-container", ".ad-wrapper", ".adwrapper",
    ".banner-ad", ".sponsored-ad", ".advertisement", "#advertisement", "#ad-container",
    "[aria-label='Advertisement' i]", "[aria-label='Advertisements' i]"
  ];
  var BROAD = [
    ".ad-banner", ".adbanner", ".advert", "#ad-banner", ".ads-container", ".ads-wrapper", ".ad-box",
    ".ad-placeholder", ".sponsored-content", ".promoted-content", "[id^='ad_']", "[class^='ad_']",
    "[id*='-ad-slot']", "[class*='adsense']"
  ];

  var level = 1;
  var style = null;

  function site(h) {
    return h.split(".").slice(-2).join(".");
  }
  var mine = site(location.hostname);

  function selectors() {
    var s = NETWORK.slice();
    if (level >= 2) s = s.concat(COMMON);
    if (level >= 3) s = s.concat(BROAD);
    return s;
  }

  // Elements that must never be hidden, whatever they are called.
  function safe(el) {
    try {
      var t = el.tagName;
      if (t === "BODY" || t === "HTML" || t === "MAIN" || t === "ARTICLE" || t === "NAV" || t === "HEADER" || t === "FORM") return true;
      if (el.closest("main, article, nav, form, [role='main'], [role='navigation'], [role='dialog']") &&
        !el.matches(NETWORK.join(","))) return true;
      if (el.querySelector("video, form, input, textarea, [role='main']")) return true;
      var r = el.getBoundingClientRect();
      var vh = window.innerHeight || 800, vw = window.innerWidth || 400;
      var share = (r.width * r.height) / (vw * vh);
      if (share > (level >= 3 ? 0.7 : 0.35)) return true;
      if (el.innerText && el.innerText.length > (level >= 3 ? 700 : 300) && !el.matches(NETWORK.join(","))) return true;
      return false;
    } catch (e) {
      return true;
    }
  }

  function hide(el) {
    if (safe(el)) return;
    el.style.setProperty("display", "none", "important");
    el.setAttribute("data-la-hidden", "1");
  }

  // True when everything inside `p` is already hidden and it holds no visible text.
  function allGone(p) {
    try {
      if (p.innerText && p.innerText.trim().length) return false;
      for (var c = p.firstElementChild; c; c = c.nextElementSibling) {
        var t = c.tagName;
        if (t === "SCRIPT" || t === "STYLE" || t === "NOSCRIPT") continue;
        if (getComputedStyle(c).display !== "none") return false;
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  function collapseParents(el) {
    if (level < 2) return;
    var p = el.parentElement;
    for (var i = 0; i < 3 && p && p !== document.body && p !== document.documentElement; i++) {
      if (safe(p) || !allGone(p)) break;
      p.style.setProperty("display", "none", "important");
      p = p.parentElement;
    }
  }

  function sweep() {
    try {
      var found = document.querySelectorAll(selectors().join(","));
      for (var i = 0; i < found.length; i++) {
        hide(found[i]);
        collapseParents(found[i]);
      }
      if (level >= 3) removeWalls();
    } catch (e) {}
  }

  // Aggressive: pages that ask you to turn the blocker off. Only fixed full-screen layers that
  // mention it are removed, and scrolling is given back.
  var WALL = /(ad\s?-?block|ads?\s+blocker|disable\s+(?:your\s+)?(?:ad|content)\s?-?block|whitelist\s+(?:us|this site)|turn off\s+(?:your\s+)?ad)/i;
  function removeWalls() {
    var els = document.querySelectorAll("div, section, aside");
    var removed = false;
    for (var i = 0; i < els.length && i < 1500; i++) {
      var el = els[i];
      var cs;
      try { cs = getComputedStyle(el); } catch (e) { continue; }
      if (cs.position !== "fixed" && cs.position !== "sticky") continue;
      var r = el.getBoundingClientRect();
      if (r.width < window.innerWidth * 0.6 || r.height < window.innerHeight * 0.3) continue;
      var txt = (el.innerText || "").slice(0, 600);
      if (txt && WALL.test(txt) && !el.querySelector("video, input[type=password]")) {
        el.style.setProperty("display", "none", "important");
        removed = true;
      }
    }
    if (removed) {
      for (var n of [document.documentElement, document.body]) {
        if (!n) continue;
        n.style.setProperty("overflow", "auto", "important");
        n.style.setProperty("position", "static", "important");
      }
    }
  }

  function start() {
    if (style || level === 0) return;
    style = document.createElement("style");
    style.textContent = NETWORK.join(",") + "{display:none!important}";
    (document.head || document.documentElement).appendChild(style);

    // A picture or frame from another site that failed to load was an ad request we cancelled.
    document.addEventListener("error", function (e) {
      var el = e.target;
      if (!el || (el.tagName !== "IMG" && el.tagName !== "IFRAME") || level < 2) return;
      try {
        var u = new URL(el.currentSrc || el.src);
        if (u.protocol.indexOf("http") !== 0 || site(u.hostname) === mine) return;
        if (!safe(el)) {
          el.style.setProperty("display", "none", "important");
          collapseParents(el);
        }
      } catch (x) {}
    }, true);

    document.addEventListener("DOMContentLoaded", sweep);
    window.addEventListener("load", function () {
      setTimeout(sweep, 800);
      setTimeout(sweep, 3000);
      if (level >= 3) setTimeout(sweep, 7000);
    });
  }

  browser.runtime.sendMessage({ t: "cfg" }).then(
    function (c) {
      if (!c || c.ads === false) return;
      level = typeof c.level === "number" ? c.level : 1;
      start();
    },
    function () {}
  );
})();
